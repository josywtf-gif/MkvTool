package com.mkvtool

import android.Manifest
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.OpenableColumns
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.*
import org.json.JSONObject
import java.io.File

data class Track(val index: Int, val type: String, val codec: String, val lang: String, val title: String, var on: Boolean = true)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MaterialTheme(colorScheme = darkColorScheme()) { Surface(Modifier.fillMaxSize()) { App() } } }
    }

    @Composable
    fun App() {
        val scope = rememberCoroutineScope()
        val bm = remember { BinaryManager(this) }
        val tracks = remember { mutableStateListOf<Track>() }
        val logs = remember { mutableStateListOf<String>() }
        var input by remember { mutableStateOf<File?>(null) }
        var duration by remember { mutableStateOf(0.0) }
        var busy by remember { mutableStateOf(false) }
        var gb by remember { mutableStateOf("1.5") }
        var preset by remember { mutableStateOf(0) }
        val logScroll = rememberScrollState()
        fun log(s: String) { logs.add(s); if (logs.size > 800) logs.removeAt(0) }

        suspend fun run(cmd: List<String>) = withContext(Dispatchers.IO) {
            log("$ " + cmd.joinToString(" "))
            try {
                val p = ProcessBuilder(cmd).redirectErrorStream(true).start()
                val sb = StringBuilder()
                p.inputStream.bufferedReader().forEachLine { l -> sb.appendLine(l); withContext(Dispatchers.Main) { log(l) } }
                p.waitFor().also { withContext(Dispatchers.Main) { log("exit=$it") } }
                sb.toString()
            } catch (e: Exception) { withContext(Dispatchers.Main) { log("ERR: ${e.message}") }; "" }
        }
        fun outFile(suffix: String): String {
            val d = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS).apply { mkdirs() }
            return File(d, input!!.nameWithoutExtension + "_$suffix.mkv").absolutePath
        }
        fun job(block: suspend () -> Unit) {
            scope.launch { busy = true; try { block() } catch (e: Exception) { log("ERR: ${e.message}") }; busy = false }
        }

        val permLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {}
        LaunchedEffect(Unit) {
            permLauncher.launch(arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE))
            if (Build.VERSION.SDK_INT >= 30 && !Environment.isExternalStorageManager()) {
                runCatching { startActivity(Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION, Uri.parse("package:$packageName"))) }
            }
            busy = true
            withContext(Dispatchers.IO) { try { bm.ensure { s -> runBlocking(Dispatchers.Main) { log(s) } } } catch (e: Exception) { withContext(Dispatchers.Main) { log("Ошибка бинарников: ${e.message}") } } }
            busy = false
        }

        val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
            if (uri == null) return@rememberLauncherForActivityResult
            job {
                tracks.clear()
                val name = contentResolver.query(uri, null, null, null, null)?.use { c ->
                    val i = c.getColumnIndex(OpenableColumns.DISPLAY_NAME); if (c.moveToFirst() && i >= 0) c.getString(i) else null } ?: "input.mkv"
                log("Копирую файл...")
                val f = File(cacheDir, name)
                withContext(Dispatchers.IO) { contentResolver.openInputStream(uri)!!.use { i -> f.outputStream().use { i.copyTo(it) } } }
                input = f
                val out = run(listOf(bm.ffprobe, "-v", "quiet", "-print_format", "json", "-show_streams", "-show_format", f.absolutePath))
                val j = JSONObject(out.substring(out.indexOf('{')))
                duration = j.optJSONObject("format")?.optString("duration")?.toDoubleOrNull() ?: 0.0
                val s = j.getJSONArray("streams")
                for (k in 0 until s.length()) {
                    val o = s.getJSONObject(k); val t = o.optJSONObject("tags")
                    tracks.add(Track(o.getInt("index"), o.optString("codec_type"), o.optString("codec_name"), t?.optString("language") ?: "und", t?.optString("title") ?: ""))
                }
            }
        }

        Column(Modifier.fillMaxSize().padding(12.dp).statusBarsPadding(), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Button({ picker.launch(arrayOf("video/*", "application/x-matroska")) }, enabled = !busy) { Text(input?.name ?: "Выбрать MKV/MP4") }
            Column(Modifier.weight(1f).verticalScroll(rememberScrollState())) {
                tracks.forEachIndexed { i, t ->
                    Row(verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
                        Checkbox(t.on, { tracks[i] = t.copy(on = it) })
                        Text("#${t.index} ${t.type} ${t.codec} [${t.lang}] ${t.title}", fontSize = 13.sp)
                    }
                }
                if (tracks.isNotEmpty()) {
                    Button({
                        job {
                            val maps = tracks.filter { it.on }.flatMap { listOf("-map", "0:${it.index}") }
                            run(listOf(bm.ffmpeg, "-y", "-i", input!!.absolutePath) + maps + listOf("-c", "copy", outFile("clean")))
                            log("Готово: Download/")
                        }
                    }, enabled = !busy) { Text("Очистить (оставить отмеченные)") }

                    Text("Компрессор звука", Modifier.padding(top = 8.dp))
                    Row { listOf("Мягкий", "Агрессивный").forEachIndexed { i, n -> FilterChip(preset == i, { preset = i }, { Text(n) }, Modifier.padding(end = 8.dp)) } }
                    Button({
                        job {
                            val af = if (preset == 0) "acompressor=threshold=0.1:ratio=3:attack=20:release=250"
                                     else "acompressor=threshold=0.03:ratio=8:attack=5:release=100,loudnorm"
                            run(listOf(bm.ffmpeg, "-y", "-i", input!!.absolutePath, "-map", "0", "-c:v", "copy", "-c:s", "copy",
                                "-af", af, "-c:a", "ac3", "-b:a", "640k", outFile("comp")))
                            log("Готово: Download/")
                        }
                    }, enabled = !busy) { Text("Сжать звук") }

                    Text("Сжатие видео", Modifier.padding(top = 8.dp))
                    OutlinedTextField(gb, { gb = it }, label = { Text("Размер, ГБ") }, singleLine = true)
                    Button({
                        job {
                            val size = gb.replace(',', '.').toDoubleOrNull() ?: return@job log("Неверный размер")
                            if (duration <= 0) return@job log("Нет длительности")
                            val total = (size * 8.0 * 1024 * 1024 * 1024 / duration).toLong()
                            val v = (total - 192_000).coerceAtLeast(100_000)
                            log("Видео-битрейт: ${v / 1000} kbps")
                            run(listOf(bm.ffmpeg, "-y", "-i", input!!.absolutePath, "-map", "0:v:0", "-map", "0:a?", "-map", "0:s?",
                                "-c:v", "libx264", "-b:v", "$v", "-maxrate", "${(v * 1.5).toLong()}", "-bufsize", "${v * 2}", "-preset", "veryfast",
                                "-c:a", "aac", "-b:a", "192k", "-c:s", "copy", outFile("small")))
                            log("Готово: Download/")
                        }
                    }, enabled = !busy) { Text("Сжать видео") }
                }
            }
            if (busy) LinearProgressIndicator(Modifier.fillMaxWidth())
            LaunchedEffect(logs.size) { logScroll.scrollTo(logScroll.maxValue) }
            Box(Modifier.fillMaxWidth().height(220.dp).verticalScroll(logScroll)) {
                Text(logs.joinToString("\n"), fontFamily = FontFamily.Monospace, fontSize = 10.sp, color = Color(0xFF88FF88))
            }
        }
    }
}
