package com.mkvtool

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

/** Информация о фильме/сериале из TMDB. */
class MovieInfo(
    val title: String,
    val year: String,
    val overview: String,
    val rating: Double,
    val votes: Int,
    val isTv: Boolean,
    val poster: Bitmap?
)

object Tmdb {
    private val TAGS = Regex(
        "(?i)\\b(2160p|1080p|1080i|720p|480p|4k|uhd|hdr10\\+?|hdr|dv|web-?dl|web-?rip|blu-?ray|bdrip|bdremux|remux|hdrip|dvdrip|hdtv|x264|x265|h\\.?264|h\\.?265|hevc|avc|aac|ac3|eac3|dts(-hd)?|atmos|truehd|ddp?5\\.?1|amzn|nf|rip|repack|proper|extended|unrated|imax|multi|dub|dubbed|sub|rus|eng)\\b"
    )
    private val YEAR = Regex("[\\(\\[]?\\b((?:19|20)\\d{2})\\b[\\)\\]]?")

    /** Из имени файла получает (название, год). */
    fun parseName(fileName: String): Pair<String, String?> {
        var n = fileName.substringBeforeLast('.', fileName)
        n = n.replace(Regex("\\[[^\\]]*\\]"), " ")           // [теги в скобках]
        n = n.replace('.', ' ').replace('_', ' ')
        val ym = YEAR.findAll(n).lastOrNull { it.range.first > 0 }
        var year: String? = null
        if (ym != null) { year = ym.groupValues[1]; n = n.substring(0, ym.range.first) }
        val tm = TAGS.find(n)
        if (tm != null && tm.range.first > 0) n = n.substring(0, tm.range.first)
        n = n.replace(Regex("[\\-–(\\[]+\\s*$"), "").replace(Regex("\\s+"), " ").trim()
        return n to year
    }

    private fun get(url: String, key: String): String? {
        val c = URL(url).openConnection() as HttpURLConnection
        try {
            c.connectTimeout = 10000; c.readTimeout = 15000
            if (key.startsWith("eyJ")) c.setRequestProperty("Authorization", "Bearer $key")
            c.setRequestProperty("Accept", "application/json")
            if (c.responseCode != 200) return if (c.responseCode == 401) "401" else null
            return c.inputStream.bufferedReader().use { it.readText() }
        } finally { c.disconnect() }
    }

    /** Возвращает MovieInfo, null если не найдено; бросает исключение при проблеме с сетью/ключом. */
    fun fetch(key: String, title: String, year: String?): MovieInfo? {
        if (title.isBlank()) return null
        val auth = if (key.startsWith("eyJ")) "" else "&api_key=${URLEncoder.encode(key, "UTF-8")}"
        val q = URLEncoder.encode(title, "UTF-8")
        fun search(kind: String, withYear: Boolean): JSONObject? {
            val y = if (withYear && year != null) (if (kind == "movie") "&year=$year" else "&first_air_date_year=$year") else ""
            val body = get("https://api.themoviedb.org/3/search/$kind?query=$q&language=ru-RU&include_adult=false$y$auth", key)
                ?: throw RuntimeException("Нет ответа от TMDB")
            if (body == "401") throw RuntimeException("Неверный ключ TMDB")
            val arr = JSONObject(body).optJSONArray("results") ?: return null
            return if (arr.length() > 0) arr.getJSONObject(0) else null
        }
        var isTv = false
        var r = search("movie", true)
        if (r == null) { r = search("tv", true); isTv = r != null }
        if (r == null) r = search("movie", false)
        if (r == null) { r = search("tv", false); isTv = r != null }
        if (r == null) return null
        val name = r.optString(if (isTv) "name" else "title")
        val date = r.optString(if (isTv) "first_air_date" else "release_date")
        var poster: Bitmap? = null
        val pp = r.optString("poster_path")
        if (pp.isNotBlank() && pp != "null") {
            runCatching {
                val c = URL("https://image.tmdb.org/t/p/w342$pp").openConnection() as HttpURLConnection
                c.connectTimeout = 10000; c.readTimeout = 20000
                poster = c.inputStream.use { BitmapFactory.decodeStream(it) }
                c.disconnect()
            }
        }
        return MovieInfo(name, date.take(4), r.optString("overview"), r.optDouble("vote_average", 0.0), r.optInt("vote_count", 0), isTv, poster)
    }
}
