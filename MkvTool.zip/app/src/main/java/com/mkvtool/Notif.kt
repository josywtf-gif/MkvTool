package com.mkvtool

import android.app.*
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.core.app.NotificationCompat

object Notif {
    private const val CH_WORK = "work"
    private const val CH_DONE = "done"
    const val ID_WORK = 1
    private const val ID_DONE = 2

    fun channels(ctx: Context) {
        if (Build.VERSION.SDK_INT >= 26) {
            val nm = ctx.getSystemService(NotificationManager::class.java)
            nm.createNotificationChannel(NotificationChannel(CH_WORK, "Обработка", NotificationManager.IMPORTANCE_LOW))
            nm.createNotificationChannel(NotificationChannel(CH_DONE, "Результат", NotificationManager.IMPORTANCE_HIGH))
        }
    }

    private fun open(ctx: Context) = PendingIntent.getActivity(
        ctx, 0, Intent(ctx, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_NEW_TASK),
        PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)

    private fun capsuleOn(ctx: Context) = ctx.getSharedPreferences("settings", Context.MODE_PRIVATE).getBoolean("capsule", false)

    /** Уведомление с процентом в заголовке и полосой прогресса. На Android 16+ при включённой настройке просит показать «капсулу» в строке состояния. */
    fun work(ctx: Context, text: String, percent: Int?): Notification {
        channels(ctx)
        val b = if (Build.VERSION.SDK_INT >= 26) Notification.Builder(ctx, CH_WORK) else Notification.Builder(ctx)
        b.setSmallIcon(android.R.drawable.stat_sys_download)
            .setContentTitle(if (percent != null) "MkvTool · $percent%" else "MkvTool")
            .setContentText(text).setContentIntent(open(ctx))
            .setOngoing(true).setOnlyAlertOnce(true)
            .setProgress(100, percent ?: 0, percent == null)
        if (Build.VERSION.SDK_INT >= 36 && capsuleOn(ctx)) {
            // API 36 (Android 16): «живые» уведомления. Через рефлексию, т.к. compileSdk ниже.
            runCatching { Notification.Builder::class.java.getMethod("setRequestPromotedOngoing", java.lang.Boolean.TYPE).invoke(b, true) }
            if (percent != null) runCatching { Notification.Builder::class.java.getMethod("setShortCriticalText", String::class.java).invoke(b, "$percent%") }
        }
        return b.build()
    }

    fun progress(ctx: Context, text: String, percent: Int) {
        (ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).notify(ID_WORK, work(ctx, text, percent))
    }

    fun done(ctx: Context, title: String, text: String) {
        channels(ctx)
        val n = NotificationCompat.Builder(ctx, CH_DONE).setSmallIcon(android.R.drawable.stat_sys_download_done)
            .setContentTitle(title).setContentText(text).setContentIntent(open(ctx)).setAutoCancel(true)
            .setPriority(NotificationCompat.PRIORITY_HIGH).build()
        (ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).notify(ID_DONE, n)
    }
}
