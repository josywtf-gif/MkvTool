package com.mkvtool

import android.Manifest
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.OpenableColumns
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.KeyboardArrowUp
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.FileProvider
import kotlinx.coroutines.*
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import java.io.File

data class Track(val index: Int, val type: String, val codec: String, val lang: String, val title: String, val extra: String, val on: Boolean = true)
class RunState { @Volatile var exit = 0; @Volatile var stopped = false; @Volatile var proc: Process? = null }

private val TIME_RE = Regex("time=(\\d+):(\\d+):(\\d+(?:\\.\\d+)?)")
private val SPEED_RE = Regex("speed=\\s*([\\d.]+)x")

fun fmtDur(sec: Double): String {
    val s = sec.toLong(); return "%d:%02d:%02d".format(s / 3600, s % 3600 / 60, s % 60)
}
fun fmtSize(b: Long): String = if (b >= 1L shl 30) "%.2f ГБ".format(b / 1073741824.0) else "%.0f МБ".format(b / 1048576.0)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { AppTheme { Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) { App() } } }
    }

    @Composable
    fun App() {
        val scope = rememberCoroutineScope()
        val bm = remember { BinaryManager(this) }
        val rs = remember { RunState() }
        val tracks = remember { mutableStateListOf<Track>() }
        val logs = remember { mutableStateListOf<String>() }
        var input by remember { mutableStateOf<File?>(null) }
        var duration by remember { mutableStateOf(0.0) }
        var busy by remember { mutableStateOf(false) }
        var status by remember { mutableStateOf("Подготовка…") }
        var progress by remember { mutableStateOf<Float?>(null) }
        var speed by remember { mutableStateOf("") }
        var logOpen by remember { mutableStateOf(false) }
        var gb by remember { mutableStateOf("1.5") }
        var preset by remember { mutableStateOf(1) }

        fun log(s: String) { logs.add(s); if (logs.size > 600) logs.removeAt(0) }

        suspend fun run(cmd: List<String>, track: Boolean = false): String = withContext(Dispatchers.IO) {
            withContext(Dispatchers.Main) { log("$ " + cmd.joinToString(" ")) }
            val sb = StringBuilder(); var code = -1
            try {
                val p = ProcessBuilder(cmd).redirectErrorStream(true).start(); rs.proc = p
                val rd = p.inputStream.bufferedReader()
                while (true) {
                    val l = rd.readLine() ?: break
                    if (track && l.contains("time=")) {
                        val m = TIME_RE.find(l)
                        if (m != null && duration > 0) {
                            val t = m.groupValues[1].toDouble() * 3600 + m.groupValues[2].toDouble() * 60 + m.groupValues[3].toDouble()
                            progress = (t / duration).coerceIn(0.0, 1.0).toFloat()
                        }
                        speed = SPEED_RE.find(l)?.groupValues?.get(1)?.let { "$it×" } ?: speed
                    } else { sb.appendLine(l); withContext(Dispatchers.Main) { log(l) } }
                }
                code = p.waitFor()
            } catch (e: Exception) { withContext(Dispatchers.Main) { log("ERR: ${e.message}") } }
            rs.proc = null; rs.exit = code
            withContext(Dispatchers.Main) { log("exit=$code") }
            sb.toString()
        }
        fun outFile(suffix: String): String {
            val d = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS).apply { mkdirs() }
            return File(d, input!!.nameWithoutExtension + "_$suffix.mkv").absolutePath
        }
        fun job(title: String, block: suspend () -> Unit) {
            if (busy) return
            scope.launch {
                busy = true; rs.stopped = false; status = title; progress = null; speed = ""
                try { block() } catch (e: Exception) { log("ERR: ${e.message}"); status = "Ошибка: ${e.message}"; progress = 0f }
                busy = false
            }
        }
        fun finish(path: String) {
            speed = ""
            if (rs.exit == 0) { status = "Готово · ${File(path).name}"; progress = 1f; log("Сохранено: $path") }
            else { File(path).delete(); status = if (rs.stopped) "Остановлено" else "Ошибка (код ${rs.exit})"; progress = 0f }
        }

        val permLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {}
        LaunchedEffect(Unit) {
            permLauncher.launch(arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE))
            if (Build.VERSION.SDK_INT >= 30 && !Environment.isExternalStorageManager()) {
                runCatching { startActivity(Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION, Uri.parse("package:$packageName"))) }
            }
            if (!bm.ready) { busy = true; status = "Первый запуск: загрузка ffmpeg…"; progress = null }
            val err = withContext(Dispatchers.IO) {
                try { bm.ensure { s -> scope.launch(Dispatchers.Main) { log(s) } }; null } catch (e: Exception) { e.message ?: "unknown" }
            }
            busy = false
            if (err != null) { status = "Ошибка загрузки ffmpeg: $err"; progress = 0f; log("Ошибка бинарников: $err") }
            else { status = "Выберите файл"; progress = 0f }
        }

        val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
            if (uri == null) return@rememberLauncherForActivityResult
            job("Копирование файла") {
                tracks.clear(); input?.delete(); input = null; duration = 0.0
                var name = "input.mkv"; var size = 0L
                contentResolver.query(uri, null, null, null, null)?.use { c ->
                    if (c.moveToFirst()) {
                        val ni = c.getColumnIndex(OpenableColumns.DISPLAY_NAME); if (ni >= 0) name = c.getString(ni) ?: name
                        val si = c.getColumnIndex(OpenableColumns.SIZE); if (si >= 0) size = c.getLong(si)
                    }
                }
                val f = File(cacheDir, name)
                withContext(Dispatchers.IO) {
                    contentResolver.openInputStream(uri)!!.use { i -> f.outputStream().use { o ->
                        val buf = ByteArray(1 shl 20); var done = 0L
                        while (true) {
                            val n = i.read(buf); if (n < 0) break
                            o.write(buf, 0, n); done += n
                            if (size > 0) progress = done.toFloat() / size
                        }
                    } }
                }
                status = "Анализ дорожек"; progress = null
                val out = run(listOf(bm.ffprobe, "-v", "quiet", "-print_format", "json", "-show_streams", "-show_format", f.absolutePath))
                if (!out.contains('{')) { status = "Не удалось прочитать файл"; progress = 0f; return@job }
                val j = JSONObject(out.substring(out.indexOf('{')))
                duration = j.optJSONObject("format")?.optString("duration")?.toDoubleOrNull() ?: 0.0
                val s = j.getJSONArray("streams")
                for (k in 0 until s.length()) {
                    val o = s.getJSONObject(k); val t = o.optJSONObject("tags")
                    val type = o.optString("codec_type")
                    val extra = when (type) {
                        "video" -> "${o.optInt("width")}×${o.optInt("height")}"
                        "audio" -> o.optString("channel_layout")
                        else -> ""
                    }
                    tracks.add(Track(o.getInt("index"), type, o.optString("codec_name"), t?.optString("language") ?: "und", t?.optString("title") ?: "", extra))
                }
                input = f
                status = "Файл готов — выберите действие"; progress = 0f
            }
        }

        fun doUpdate() = job("Проверка обновления") {
            val apk = withContext(Dispatchers.IO) {
                val c = OkHttpClient()
                val j = JSONObject(c.newCall(Request.Builder().url("https://api.github.com/repos/${BuildConfig.REPO}/releases/latest").build()).execute().body!!.string())
                val tag = j.optString("tag_name").removePrefix("v").toIntOrNull()
                if (tag == null || tag <= BuildConfig.VERSION_CODE) { status = "Установлена последняя версия (v${BuildConfig.VERSION_CODE})"; progress = 0f; return@withContext null }
                val a = j.getJSONArray("assets"); var url: String? = null
                for (i in 0 until a.length()) if (a.getJSONObject(i).getString("name").endsWith(".apk")) url = a.getJSONObject(i).getString("browser_download_url")
                if (url == null) return@withContext null
                status = "Скачивание обновления v$tag…"
                val f = File(cacheDir, "update.apk")
                c.newCall(Request.Builder().url(url).build()).execute().body!!.byteStream().use { i -> f.outputStream().use { i.copyTo(it) } }
                f
            }
            if (apk != null) {
                if (Build.VERSION.SDK_INT >= 26 && !packageManager.canRequestPackageInstalls()) {
                    status = "Разреши установку и нажми «Обновить» ещё раз"; progress = 0f
                    startActivity(Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:$packageName")))
                } else {
                    status = "Установка…"; progress = 0f
                    startActivity(Intent(Intent.ACTION_VIEW).apply {
                        setDataAndType(FileProvider.getUriForFile(this@MainActivity, "$packageName.fp", apk), "application/vnd.android.package-archive")
                        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
                    })
                }
            }
        }

        Column(Modifier.fillMaxSize().statusBarsPadding()) {
            // Верхняя панель
            Row(Modifier.fillMaxWidth().padding(start = 20.dp, end = 8.dp, top = 12.dp, bottom = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("MkvTool", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                    Text("v${BuildConfig.VERSION_CODE}", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                TextButton(onClick = { doUpdate() }, enabled = !busy) { Text("Обновить") }
            }

            // Контент
            Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(horizontal = 16.dp, vertical = 8.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                SectionCard("1 · Файл") {
                    val f = input
                    if (f == null) {
                        Text("Выберите видео MKV или MP4, чтобы увидеть дорожки и доступные действия.", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    } else {
                        Text(f.name, style = MaterialTheme.typography.bodyLarge, fontWeight = FontWeight.Medium, maxLines = 2, overflow = TextOverflow.Ellipsis)
                        Text("${fmtDur(duration)} · ${fmtSize(f.length())} · ${tracks.size} дорожек", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    FilledTonalButton({ picker.launch(arrayOf("video/*", "application/x-matroska")) }, enabled = !busy, modifier = Modifier.fillMaxWidth().height(48.dp), shape = RoundedCornerShape(14.dp)) {
                        Text(if (input == null) "Выбрать файл" else "Выбрать другой файл")
                    }
                }

                if (input != null) {
                    SectionCard("2 · Дорожки", "Выбрано ${tracks.count { it.on }} из ${tracks.size}. Нажмите на строку, чтобы включить или убрать.") {
                        tracks.forEachIndexed { i, t -> TrackRow(t) { tracks[i] = t.copy(on = it) } }
                        Button({
                            job("Очистка дорожек") {
                                val maps = tracks.filter { it.on }.flatMap { listOf("-map", "0:${it.index}") }
                                if (maps.isEmpty()) { status = "Выберите хотя бы одну дорожку"; progress = 0f; return@job }
                                val out = outFile("clean")
                                run(listOf(bm.ffmpeg, "-hide_banner", "-y", "-i", input!!.absolutePath) + maps + listOf("-c", "copy", out), track = true)
                                finish(out)
                            }
                        }, enabled = !busy, modifier = Modifier.fillMaxWidth().height(48.dp), shape = RoundedCornerShape(14.dp)) { Text("Сохранить только выбранные") }
                    }

                    SectionCard("3 · Выравнивание громкости", "Сжимает динамический диапазон: тихие реплики громче, взрывы тише. Звук станет AC3, видео не перекодируется.") {
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            listOf("Мягкий", "Баланс", "Агрессивный").forEachIndexed { i, n ->
                                FilterChip(preset == i, { preset = i }, { Text(n, maxLines = 1, fontSize = 13.sp) }, Modifier.weight(1f))
                            }
                        }
                        Text(listOf("Лёгкая коррекция, звук почти не меняется.", "Золотая середина для просмотра вечером.", "Сильное выравнивание + нормализация громкости.")[preset],
                            style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Button({
                            job("Обработка звука") {
                                val af = when (preset) {
                                    0 -> "acompressor=threshold=0.1:ratio=3:attack=20:release=250"
                                    1 -> "acompressor=threshold=0.06:ratio=5:attack=10:release=150,volume=1.5"
                                    else -> "acompressor=threshold=0.03:ratio=8:attack=5:release=100,loudnorm"
                                }
                                val out = outFile("comp")
                                run(listOf(bm.ffmpeg, "-hide_banner", "-y", "-i", input!!.absolutePath, "-map", "0", "-c:v", "copy", "-c:s", "copy",
                                    "-af", af, "-c:a", "ac3", "-b:a", "640k", out), track = true)
                                finish(out)
                            }
                        }, enabled = !busy, modifier = Modifier.fillMaxWidth().height(48.dp), shape = RoundedCornerShape(14.dp)) { Text("Обработать звук") }
                    }

                    SectionCard("4 · Сжатие видео", "Укажите желаемый размер файла — битрейт рассчитается автоматически.") {
                        OutlinedTextField(gb, { gb = it }, label = { Text("Целевой размер") }, suffix = { Text("ГБ") }, singleLine = true,
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(14.dp))
                        val gbVal = gb.replace(',', '.').toDoubleOrNull()
                        val kbps = if (gbVal != null && duration > 0) ((gbVal * 8.0 * 1024 * 1024 * 1024 / duration - 192_000) / 1000).toLong() else null
                        val hint = when {
                            kbps == null -> "Введите размер числом"
                            gbVal != null && gbVal * 1073741824.0 >= (input?.length() ?: 0L) -> "Это не меньше исходного файла"
                            kbps < 100 -> "Слишком маленький размер для этой длительности"
                            else -> "Видео-битрейт ≈ $kbps кбит/с, звук AAC 192 кбит/с"
                        }
                        Text(hint, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Button({
                            job("Сжатие видео") {
                                val size = gbVal ?: run { status = "Неверный размер"; progress = 0f; return@job }
                                if (duration <= 0) { status = "Неизвестна длительность файла"; progress = 0f; return@job }
                                val v = ((size * 8.0 * 1024 * 1024 * 1024 / duration).toLong() - 192_000).coerceAtLeast(100_000)
                                val encs = run(listOf(bm.ffmpeg, "-hide_banner", "-encoders"))
                                val enc = listOf("libx264", "h264_mediacodec", "libx265", "mpeg4").firstOrNull { encs.contains(" $it ") } ?: "mpeg4"
                                log("Кодер: $enc, битрейт ${v / 1000} кбит/с")
                                val extra = if (enc == "libx264") listOf("-preset", "veryfast") else emptyList()
                                val out = outFile("small")
                                run(listOf(bm.ffmpeg, "-hide_banner", "-y", "-i", input!!.absolutePath, "-map", "0:v:0", "-map", "0:a?", "-map", "0:s?",
                                    "-c:v", enc, "-b:v", "$v", "-maxrate", "${(v * 1.5).toLong()}", "-bufsize", "${v * 2}") + extra +
                                    listOf("-c:a", "aac", "-b:a", "192k", "-c:s", "copy", out), track = true)
                                finish(out)
                            }
                        }, enabled = !busy, modifier = Modifier.fillMaxWidth().height(48.dp), shape = RoundedCornerShape(14.dp)) { Text("Сжать видео") }
                    }
                }
                Spacer(Modifier.height(8.dp))
            }

            // Нижняя панель: прогресс + выдвижной лог
            Surface(Modifier.fillMaxWidth(), color = MaterialTheme.colorScheme.surfaceContainerHigh,
                shape = RoundedCornerShape(topStart = 24.dp, topEnd = 24.dp), shadowElevation = 8.dp) {
                Column(Modifier.navigationBarsPadding().padding(horizontal = 16.dp, vertical = 6.dp)) {
                    Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).clickable { logOpen = !logOpen }.padding(vertical = 2.dp),
                        horizontalArrangement = Arrangement.Center, verticalAlignment = Alignment.CenterVertically) {
                        Icon(if (logOpen) Icons.Filled.KeyboardArrowDown else Icons.Filled.KeyboardArrowUp, contentDescription = "Лог")
                        Text("Лог", style = MaterialTheme.typography.labelLarge)
                    }
                    val p = progress
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(status, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Medium, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            if (speed.isNotEmpty()) Text("скорость $speed", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        if (p != null) Text("${(p * 100).toInt()}%", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                        if (busy && progress != null) TextButton(onClick = { rs.stopped = true; rs.proc?.destroy() }) { Text("Стоп") }
                    }
                    val bar = Modifier.fillMaxWidth().height(8.dp).clip(RoundedCornerShape(4.dp))
                    if (busy && p == null) LinearProgressIndicator(bar) else LinearProgressIndicator(progress = { p ?: 0f }, modifier = bar)
                    AnimatedVisibility(logOpen, enter = expandVertically(expandFrom = Alignment.Bottom) + fadeIn(), exit = shrinkVertically(shrinkTowards = Alignment.Bottom) + fadeOut()) {
                        val sc = rememberScrollState()
                        LaunchedEffect(logs.size) { sc.scrollTo(sc.maxValue) }
                        Box(Modifier.fillMaxWidth().padding(top = 10.dp, bottom = 6.dp).height(240.dp).clip(RoundedCornerShape(12.dp)).background(Color(0xFF101418)).verticalScroll(sc).padding(10.dp)) {
                            SelectionContainer { Text(logs.joinToString("\n"), fontFamily = FontFamily.Monospace, fontSize = 11.sp, color = Color(0xFFB8F5B8)) }
                        }
                    }
                    Spacer(Modifier.height(6.dp))
                }
            }
        }
    }
}

@Composable
fun AppTheme(content: @Composable () -> Unit) {
    val dark = isSystemInDarkTheme()
    val ctx = LocalContext.current
    val cs = when {
        Build.VERSION.SDK_INT >= 31 -> if (dark) dynamicDarkColorScheme(ctx) else dynamicLightColorScheme(ctx)
        dark -> darkColorScheme()
        else -> lightColorScheme()
    }
    MaterialTheme(colorScheme = cs, content = content)
}

@Composable
fun SectionCard(title: String, subtitle: String? = null, content: @Composable ColumnScope.() -> Unit) {
    Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(20.dp), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerHigh)) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text(title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
            if (subtitle != null) Text(subtitle, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            content()
        }
    }
}

@Composable
fun TrackRow(t: Track, onToggle: (Boolean) -> Unit) {
    val cs = MaterialTheme.colorScheme
    val (label, bg, fg) = when (t.type) {
        "video" -> Triple("ВИДЕО", cs.primaryContainer, cs.onPrimaryContainer)
        "audio" -> Triple("АУДИО", cs.tertiaryContainer, cs.onTertiaryContainer)
        "subtitle" -> Triple("СУБТ", cs.secondaryContainer, cs.onSecondaryContainer)
        else -> Triple(t.type.uppercase(), cs.surfaceVariant, cs.onSurfaceVariant)
    }
    Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).clickable { onToggle(!t.on) }.padding(vertical = 2.dp), verticalAlignment = Alignment.CenterVertically) {
        Checkbox(t.on, null)
        Spacer(Modifier.width(6.dp))
        Box(Modifier.clip(RoundedCornerShape(6.dp)).background(bg).padding(horizontal = 6.dp, vertical = 2.dp)) {
            Text(label, color = fg, fontSize = 10.sp, fontWeight = FontWeight.Bold)
        }
        Spacer(Modifier.width(10.dp))
        Column(Modifier.weight(1f)) {
            Text("#${t.index} ${t.codec.uppercase()}" + if (t.extra.isNotEmpty()) " · ${t.extra}" else "", style = MaterialTheme.typography.bodyMedium, maxLines = 1, overflow = TextOverflow.Ellipsis)
            val sub = listOf(t.lang, t.title).filter { it.isNotBlank() }.joinToString(" · ")
            if (sub.isNotEmpty()) Text(sub, style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
    }
}
