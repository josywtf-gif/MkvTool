package com.mkvtool

import android.Manifest
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.OpenableColumns
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.KeyboardArrowUp
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.FileProvider
import kotlinx.coroutines.*
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import java.io.File

data class Track(val index: Int, val type: String, val codec: String, val lang: String, val title: String,
                 val w: Int, val h: Int, val ch: Int, val bps: Long, val fps: Double, val on: Boolean = true)
class RunState { @Volatile var exit = 0; @Volatile var stopped = false; @Volatile var proc: Process? = null }

private val TIME_RE = Regex("time=(\\d+):(\\d+):(\\d+(?:\\.\\d+)?)")
private val SPEED_RE = Regex("speed=\\s*([\\d.]+)x")

fun fmtDur(sec: Double): String {
    val s = sec.toLong(); return "%d:%02d:%02d".format(s / 3600, s % 3600 / 60, s % 60)
}
fun fmtBps(b: Long): String = when { b <= 0 -> "—"; b >= 1_000_000 -> "%.1f Мбит/с".format(b / 1e6); else -> "%.0f кбит/с".format(b / 1e3) }
fun chLabel(n: Int): String = when (n) { 1 -> "1.0"; 2 -> "2.0"; 6 -> "5.1"; 8 -> "7.1"; else -> "$n кан." }
val PRESETS = listOf(
    Triple("Мягкий", "Деликатное выравнивание: громкое чуть тише, диалоги разборчивее, динамика сохраняется.", "acompressor=threshold=-20dB:ratio=2.5:attack=20:release=300:makeup=2dB:knee=6dB"),
    Triple("Средний", "Заметнее: взрывы не бьют по ушам, голоса выходят вперёд.", "acompressor=threshold=-22dB:ratio=4:attack=15:release=250:makeup=4dB:knee=4dB"),
    Triple("Сильный", "Эффект «телевизора»: почти одна громкость, для ночного просмотра.", "acompressor=threshold=-24dB:ratio=6:attack=10:release=200:makeup=6dB:knee=2dB")
)
fun audioOutBps(sel: List<Track>, on: Boolean, br51: Int, brSt: Int): Long =
    sel.filter { it.type == "audio" }.sumOf { if (on) (if (it.ch >= 6) br51 else brSt) * 1000L else if (it.bps > 0) it.bps else 192_000L }
fun videoTargetBps(gb: Double, duration: Double, audioBps: Long): Long =
    ((gb * 8.0 * 1024 * 1024 * 1024 / duration * 0.98).toLong() - audioBps).coerceAtLeast(100_000)
fun parseFps(s: String): Double {
    val p = s.split("/")
    val d = p.getOrNull(1)?.toDoubleOrNull() ?: 0.0
    return if (p.size == 2 && d != 0.0) (p[0].toDoubleOrNull() ?: 24.0) / d else s.toDoubleOrNull()?.takeIf { it > 0 } ?: 24.0
}
fun fmtTime(sec: Double): String = when {
    sec < 60 -> "< 1 мин"
    sec < 3600 -> "~${(sec / 60).toInt()} мин"
    else -> "~${(sec / 3600).toInt()} ч ${"%02d".format((sec % 3600 / 60).toInt())} мин"
}
val SPEEDS = listOf(Triple("Быстро", "veryfast", 1.6), Triple("Баланс", "medium", 0.7), Triple("Качество", "slow", 0.35))
val SPEED_NOTES = listOf("Быстрее всего, но при том же размере качество картинки ниже.", "Золотая середина скорости и качества.", "Лучшее качество при том же размере, но обработка очень долгая.")
fun encSpeed(idx: Int, pixels: Int, fps: Double, cal: FloatArray): Double {
    val base = if (cal[idx] > 0) cal[idx].toDouble() else SPEEDS[idx].third
    return base * 2_073_600.0 / pixels.coerceAtLeast(1) * (24.0 / fps.coerceIn(24.0, 60.0))
}
data class Plan(val encode: Boolean, val outW: Int, val outH: Int, val fps: Double, val vBps: Long, val aBps: Long,
                val size: Long, val time: Double, val bpp: Double, val error: String?, val hasVideo: Boolean)
fun buildPlan(tracks: List<Track>, fileLen: Long, duration: Double, videoOn: Boolean, gb: Double?, scaleOn: Boolean, scaleH: Int,
              audioOn: Boolean, br51: Int, brSt: Int, speed: Int, cal: FloatArray): Plan {
    val sel = tracks.filter { it.on }
    val mv = sel.firstOrNull { it.type == "video" && it.w > 0 && it.codec !in listOf("mjpeg", "png", "bmp") }
    val encode = mv != null && (videoOn || scaleOn)
    val outW = if (encode && scaleOn) scaleH * 16 / 9 else mv?.w ?: 0
    val outH = if (encode && scaleOn) scaleH else mv?.h ?: 0
    val fps = mv?.fps ?: 24.0
    val aSelOrig = sel.filter { it.type == "audio" }.sumOf { if (it.bps > 0) it.bps else 192_000L }
    val aBps = audioOutBps(sel, audioOn, br51, brSt)
    val dur = maxOf(duration, 1.0)
    val origV = if (mv == null) 0L else if (mv.bps > 0) mv.bps else maxOf(500_000L, (fileLen * 8 / dur).toLong() - aSelOrig)
    var err: String? = null
    val vBps: Long
    val size: Long
    if (encode && videoOn) {
        if (gb == null) err = "Введите размер числом" else if (duration <= 0) err = "Неизвестна длительность файла"
        vBps = if (gb != null && duration > 0) videoTargetBps(gb, duration, aBps) else origV
        size = ((vBps + aBps) * dur / 8 * 1.02).toLong()
    } else {
        vBps = origV
        val removed = tracks.filter { !it.on }.sumOf { it.bps } * dur / 8
        val audioDelta = if (audioOn) (aBps - aSelOrig) * dur / 8 else 0.0
        size = (fileLen - removed + audioDelta).toLong().coerceAtLeast(0)
    }
    val time = if (encode) dur / encSpeed(speed, outW * outH, fps, cal) else fileLen / 60e6 + (if (audioOn) dur / 40 else 0.0)
    val bpp = if (encode && outW > 0) vBps / (outW.toDouble() * outH * fps.coerceAtLeast(1.0)) else 0.0
    return Plan(encode, outW, outH, fps, vBps, aBps, size, time, bpp, err, mv != null)
}
fun qualityText(p: Plan): String = when {
    !p.hasVideo -> "—"
    !p.encode -> "Оригинал, видео не перекодируется"
    else -> (if (p.bpp < 0.04) "Низкое" else if (p.bpp < 0.07) "Среднее" else if (p.bpp < 0.11) "Хорошее" else "Отличное") + " (${"%.3f".format(p.bpp)} бит/пикс.)"
}
fun fmtSize(b: Long): String = if (b >= 1L shl 30) "%.2f ГБ".format(b / 1073741824.0) else "%.0f МБ".format(b / 1048576.0)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { AppTheme { Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) { App() } } }
    }

    @Composable
    fun App() {
        val scope = rememberCoroutineScope()
        val bm = remember { BinaryManager(this) }
        val rs = remember { RunState() }
        val tracks = remember { mutableStateListOf<Track>() }
        val logs = remember { mutableStateListOf<String>() }
        var input by remember { mutableStateOf<File?>(null) }
        var duration by remember { mutableStateOf(0.0) }
        var busy by remember { mutableStateOf(false) }
        var status by remember { mutableStateOf("Подготовка…") }
        var progress by remember { mutableStateOf<Float?>(null) }
        var speedTxt by remember { mutableStateOf("") }
        var logOpen by remember { mutableStateOf(false) }
        var gb by remember { mutableStateOf("1.5") }
        var preset by remember { mutableStateOf(1) }
        var videoOn by remember { mutableStateOf(false) }
        var audioOn by remember { mutableStateOf(false) }
        var br51 by remember { mutableStateOf(448) }
        var brSt by remember { mutableStateOf(192) }
        var scaleOn by remember { mutableStateOf(false) }
        var scaleH by remember { mutableStateOf(1080) }
        var speed by remember { mutableStateOf(1) }
        var calTick by remember { mutableStateOf(0) }
        var updateInfo by remember { mutableStateOf<Pair<Int, String>?>(null) }
        val prefs = remember { getSharedPreferences("cal", MODE_PRIVATE) }
        val cal = remember(calTick) { FloatArray(3) { prefs.getFloat("cal_$it", 0f) } }

        fun log(s: String) { logs.add(s); if (logs.size > 600) logs.removeAt(0) }

        suspend fun run(cmd: List<String>, track: Boolean = false): String = withContext(Dispatchers.IO) {
            withContext(Dispatchers.Main) { log("$ " + cmd.joinToString(" ")) }
            val sb = StringBuilder(); var code = -1
            try {
                val p = ProcessBuilder(cmd).redirectErrorStream(true).start(); rs.proc = p
                val rd = p.inputStream.bufferedReader()
                while (true) {
                    val l = rd.readLine() ?: break
                    if (track && l.contains("time=")) {
                        val m = TIME_RE.find(l)
                        if (m != null && duration > 0) {
                            val t = m.groupValues[1].toDouble() * 3600 + m.groupValues[2].toDouble() * 60 + m.groupValues[3].toDouble()
                            progress = (t / duration).coerceIn(0.0, 1.0).toFloat()
                        }
                        speedTxt = SPEED_RE.find(l)?.groupValues?.get(1)?.let { "$it×" } ?: speedTxt
                    } else { sb.appendLine(l); withContext(Dispatchers.Main) { log(l) } }
                }
                code = p.waitFor()
            } catch (e: Exception) { withContext(Dispatchers.Main) { log("ERR: ${e.message}") } }
            rs.proc = null; rs.exit = code
            withContext(Dispatchers.Main) { log("exit=$code") }
            sb.toString()
        }
        fun outFile(suffix: String): String {
            val d = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS).apply { mkdirs() }
            return File(d, input!!.nameWithoutExtension + "_$suffix.mkv").absolutePath
        }
        fun job(title: String, block: suspend () -> Unit) {
            if (busy) return
            scope.launch {
                busy = true; rs.stopped = false; status = title; progress = null; speedTxt = ""
                try { block() } catch (e: Exception) { log("ERR: ${e.message}"); status = "Ошибка: ${e.message}"; progress = 0f }
                busy = false
            }
        }
        fun finish(path: String) {
            speedTxt = ""
            if (rs.exit == 0) { status = "Готово · ${File(path).name}"; progress = 1f; log("Сохранено: $path") }
            else { File(path).delete(); status = if (rs.stopped) "Остановлено" else "Ошибка (код ${rs.exit})"; progress = 0f }
        }

        fun clearFile() = job("Очистка кеша") {
            withContext(Dispatchers.IO) { cacheDir.listFiles()?.forEach { it.deleteRecursively() } }
            tracks.clear(); input = null; duration = 0.0
            status = "Файл убран, кеш очищен"; progress = 0f
        }

        val permLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {}
        LaunchedEffect(Unit) {
            permLauncher.launch(arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE))
            if (Build.VERSION.SDK_INT >= 30 && !Environment.isExternalStorageManager()) {
                runCatching { startActivity(Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION, Uri.parse("package:$packageName"))) }
            }
            withContext(Dispatchers.IO) { cacheDir.listFiles()?.forEach { it.deleteRecursively() } }
            if (!bm.ready) { busy = true; status = "Первый запуск: загрузка ffmpeg…"; progress = null }
            val err = withContext(Dispatchers.IO) {
                try { bm.ensure { s -> scope.launch(Dispatchers.Main) { log(s) } }; null } catch (e: Exception) { e.message ?: "unknown" }
            }
            busy = false
            if (err != null) { status = "Ошибка загрузки ffmpeg: $err"; progress = 0f; log("Ошибка бинарников: $err") }
            else { status = "Выберите файл"; progress = 0f }
        }

        val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
            if (uri == null) return@rememberLauncherForActivityResult
            job("Копирование файла") {
                tracks.clear(); input = null; duration = 0.0
                withContext(Dispatchers.IO) { cacheDir.listFiles()?.forEach { it.deleteRecursively() } }
                var name = "input.mkv"; var size = 0L
                contentResolver.query(uri, null, null, null, null)?.use { c ->
                    if (c.moveToFirst()) {
                        val ni = c.getColumnIndex(OpenableColumns.DISPLAY_NAME); if (ni >= 0) name = c.getString(ni) ?: name
                        val si = c.getColumnIndex(OpenableColumns.SIZE); if (si >= 0) size = c.getLong(si)
                    }
                }
                val f = File(cacheDir, name)
                withContext(Dispatchers.IO) {
                    contentResolver.openInputStream(uri)!!.use { i -> f.outputStream().use { o ->
                        val buf = ByteArray(1 shl 20); var done = 0L
                        while (true) {
                            val n = i.read(buf); if (n < 0) break
                            o.write(buf, 0, n); done += n
                            if (size > 0) progress = done.toFloat() / size
                        }
                    } }
                }
                status = "Анализ дорожек"; progress = null
                val out = run(listOf(bm.ffprobe, "-v", "quiet", "-print_format", "json", "-show_streams", "-show_format", f.absolutePath))
                if (!out.contains('{')) { status = "Не удалось прочитать файл"; progress = 0f; return@job }
                val j = JSONObject(out.substring(out.indexOf('{')))
                duration = j.optJSONObject("format")?.optString("duration")?.toDoubleOrNull() ?: 0.0
                val s = j.getJSONArray("streams")
                val fmtBr = j.optJSONObject("format")?.optString("bit_rate")?.toLongOrNull() ?: 0L
                val parsed = mutableListOf<Track>()
                for (k in 0 until s.length()) {
                    val o = s.getJSONObject(k); val t = o.optJSONObject("tags")
                    var bps = o.optString("bit_rate").toLongOrNull() ?: 0L
                    if (bps <= 0 && t != null) { val key = t.keys().asSequence().firstOrNull { it.startsWith("BPS") }; if (key != null) bps = t.optString(key).toLongOrNull() ?: 0L }
                    parsed.add(Track(o.getInt("index"), o.optString("codec_type"), o.optString("codec_name"), t?.optString("language") ?: "und", t?.optString("title") ?: "",
                        o.optInt("width"), o.optInt("height"), o.optInt("channels"), bps, parseFps(o.optString("avg_frame_rate"))))
                }
                val vi = parsed.indexOfFirst { it.type == "video" && it.w > 0 && it.bps <= 0 }
                if (vi >= 0 && fmtBr > 0) {
                    val rest = parsed.filter { it.index != parsed[vi].index }.sumOf { it.bps }
                    if (fmtBr > rest) parsed[vi] = parsed[vi].copy(bps = fmtBr - rest)
                }
                tracks.addAll(parsed)
                input = f
                status = "Файл готов — выберите действие"; progress = 0f
            }
        }

        fun installApk(apk: File) {
            if (Build.VERSION.SDK_INT >= 26 && !packageManager.canRequestPackageInstalls()) {
                status = "Разреши установку и нажми «Обновить» ещё раз"; progress = 0f
                startActivity(Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:$packageName")))
            } else {
                status = "Установка…"; progress = 0f
                startActivity(Intent(Intent.ACTION_VIEW).apply {
                    setDataAndType(FileProvider.getUriForFile(this@MainActivity, "$packageName.fp", apk), "application/vnd.android.package-archive")
                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
                })
            }
        }
        fun downloadUpdate(tag: Int, url: String) = job("Скачивание обновления v$tag") {
            val f = File(cacheDir, "update.apk")
            withContext(Dispatchers.IO) {
                val body = OkHttpClient().newCall(Request.Builder().url(url).build()).execute().body!!
                val total = body.contentLength()
                body.byteStream().use { i -> f.outputStream().use { o ->
                    val buf = ByteArray(65536); var done = 0L
                    while (true) { val n = i.read(buf); if (n < 0) break; o.write(buf, 0, n); done += n; if (total > 0) progress = done.toFloat() / total }
                } }
            }
            installApk(f)
        }
        fun doUpdate() = job("Проверка обновления") {
            val info = withContext(Dispatchers.IO) {
                val j = JSONObject(OkHttpClient().newCall(Request.Builder().url("https://api.github.com/repos/${BuildConfig.REPO}/releases/latest").build()).execute().body!!.string())
                val tag = j.optString("tag_name").removePrefix("v").toIntOrNull()
                var url: String? = null
                val a = j.optJSONArray("assets")
                if (a != null) for (i in 0 until a.length()) if (a.getJSONObject(i).getString("name").endsWith(".apk")) url = a.getJSONObject(i).getString("browser_download_url")
                if (tag != null && tag > BuildConfig.VERSION_CODE && url != null) tag to url else null
            }
            progress = 0f
            if (info == null) status = "Установлена последняя версия (v${BuildConfig.VERSION_CODE})"
            else { status = "Доступна версия v${info.first}"; updateInfo = info }
        }

        updateInfo?.let { (tag, url) ->
            AlertDialog(
                onDismissRequest = { updateInfo = null },
                title = { Text("Доступно обновление") },
                text = { Text("Новая версия v$tag (сейчас v${BuildConfig.VERSION_CODE}). Скачать и установить поверх текущей?") },
                confirmButton = { TextButton({ updateInfo = null; downloadUpdate(tag, url) }) { Text("Скачать") } },
                dismissButton = { TextButton({ updateInfo = null }) { Text("Не сейчас") } }
            )
        }
        Column(Modifier.fillMaxSize().statusBarsPadding()) {
            // Верхняя панель
            Row(Modifier.fillMaxWidth().padding(start = 20.dp, end = 8.dp, top = 12.dp, bottom = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("MkvTool", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                    Text("v${BuildConfig.VERSION_CODE}", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                TextButton(onClick = { doUpdate() }, enabled = !busy) { Text("Обновить") }
            }

            // Контент
            Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(horizontal = 16.dp, vertical = 8.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                SectionCard("1 · Файл") {
                    val f = input
                    if (f == null) {
                        Text("Выберите видео MKV или MP4, чтобы увидеть дорожки и доступные действия.", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    } else {
                        Text(f.name, style = MaterialTheme.typography.bodyLarge, fontWeight = FontWeight.Medium, maxLines = 2, overflow = TextOverflow.Ellipsis)
                        Text("${fmtDur(duration)} · ${fmtSize(f.length())} · ${tracks.size} дорожек", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        tracks.firstOrNull { it.type == "video" && it.w > 0 }?.let { InfoLine("Видео", "${it.w}×${it.h} · ${"%.2f".format(it.fps)} fps · ${it.codec.uppercase()} · ${fmtBps(it.bps)}") }
                        tracks.filter { it.type == "audio" }.forEach { InfoLine("Звук ${it.lang}", "${chLabel(it.ch)} · ${it.codec.uppercase()} · ${fmtBps(it.bps)}") }
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        FilledTonalButton({ picker.launch(arrayOf("video/*", "application/x-matroska")) }, enabled = !busy, modifier = Modifier.weight(1f).height(48.dp), shape = RoundedCornerShape(14.dp)) {
                            Text(if (input == null) "Выбрать файл" else "Другой файл")
                        }
                        if (input != null) OutlinedButton({ clearFile() }, enabled = !busy, modifier = Modifier.weight(1f).height(48.dp), shape = RoundedCornerShape(14.dp)) { Text("Очистить") }
                    }
                }

                if (input != null) {
                    SectionCard("2 · Дорожки", "Выбрано ${tracks.count { it.on }} из ${tracks.size}. Нажмите на строку, чтобы включить или убрать.") {
                        tracks.forEachIndexed { i, t -> TrackRow(t) { tracks[i] = t.copy(on = it) } }
                    }

                    val sel = tracks.filter { it.on }
                    val aSel = sel.filter { it.type == "audio" }
                    val gbVal = gb.replace(',', '.').toDoubleOrNull()
                    val plan = buildPlan(tracks, input?.length() ?: 0L, duration, videoOn, gbVal, scaleOn, scaleH, audioOn, br51, brSt, speed, cal)

                    ToggleCard("Сжать видео", "Перекодирование в H.264 до нужного размера файла.", videoOn, { videoOn = it }, !busy) {
                        OutlinedTextField(gb, { gb = it }, label = { Text("Целевой размер файла") }, suffix = { Text("ГБ") }, singleLine = true,
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(14.dp))
                        val hint = when {
                            gbVal == null -> "Введите размер числом"
                            duration <= 0 -> "Неизвестна длительность"
                            gbVal * 1073741824.0 >= (input?.length() ?: 0L) -> "Это не меньше исходного файла"
                            else -> "Видео-битрейт ≈ ${fmtBps(plan.vBps)}"
                        }
                        Text(hint, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }

                    ToggleCard("Привести к 16:9", "Добавит чёрные полосы по краям. Видео будет перекодировано; меньшее изображение увеличится.", scaleOn, { scaleOn = it }, !busy) {
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            listOf(720 to "720p · 1280×720", 1080 to "1080p · 1920×1080").forEach { (h, l) ->
                                FilterChip(scaleH == h, { scaleH = h }, { Text(l, maxLines = 1, fontSize = 13.sp) }, Modifier.weight(1f))
                            }
                        }
                    }

                    if (plan.encode) {
                        SectionCard("Скорость кодирования", "Чем быстрее, тем хуже качество картинки при том же размере файла.") {
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                SPEEDS.forEachIndexed { i, sp ->
                                    FilterChip(speed == i, { speed = i }, {
                                        Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
                                            Text(sp.first, fontSize = 13.sp, maxLines = 1)
                                            Text(fmtTime(duration / encSpeed(i, plan.outW * plan.outH, plan.fps, cal)), fontSize = 11.sp, maxLines = 1)
                                        }
                                    }, Modifier.weight(1f))
                                }
                            }
                            Text(SPEED_NOTES[speed], style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            Text(if (cal[speed] > 0) "Время рассчитано по прошлой обработке на этом телефоне." else "Время примерное; после первой обработки уточнится.",
                                style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }

                    ToggleCard("Сжать звук", "Компрессор выравнивает громкость, звук кодируется в AC-3.", audioOn, { audioOn = it }, !busy) {
                        Text("Пресет", style = MaterialTheme.typography.labelLarge)
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            PRESETS.forEachIndexed { i, pr -> FilterChip(preset == i, { preset = i }, { Text(pr.first, maxLines = 1, fontSize = 13.sp) }, Modifier.weight(1f)) }
                        }
                        Text(PRESETS[preset].second, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        if (aSel.any { it.ch >= 6 }) {
                            Text("Битрейт для 5.1", style = MaterialTheme.typography.labelLarge)
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) { listOf(448, 640).forEach { b -> FilterChip(br51 == b, { br51 = b }, { Text("$b кбит/с") }) } }
                        }
                        if (aSel.any { it.ch < 6 }) {
                            Text("Битрейт для стерео", style = MaterialTheme.typography.labelLarge)
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) { listOf(192, 256).forEach { b -> FilterChip(brSt == b, { brSt = b }, { Text("$b кбит/с") }) } }
                        }
                        if (aSel.isEmpty()) Text("Не выбрано ни одной аудиодорожки", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.error)
                    }

                    SectionCard("Результат") {
                        val removedN = tracks.count { !it.on }
                        val applied = buildList {
                            if (removedN > 0) add("• Убрано дорожек: $removedN")
                            if (plan.encode && videoOn) add("• Видео сжато до ${gb.replace(',', '.')} ГБ")
                            if (plan.encode && scaleOn) add("• ${scaleH}p, полосы до 16:9")
                            if (plan.encode) add("• Скорость кодирования: ${SPEEDS[speed].first}")
                            if (audioOn && aSel.isNotEmpty()) add("• Звук: ${PRESETS[preset].first}, AC-3" + (if (aSel.any { it.ch >= 6 }) " 5.1 ${br51}k" else "") + (if (aSel.any { it.ch < 6 }) " стерео ${brSt}k" else ""))
                        }
                        Text(if (applied.isEmpty()) "Изменений нет — будет простая пересборка файла." else applied.joinToString("\n"), style = MaterialTheme.typography.bodyMedium)
                        HorizontalDivider()
                        if (plan.error != null) Text(plan.error, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodyMedium)
                        InfoLine("Время", fmtTime(plan.time), 96.dp)
                        InfoLine("Вес", "≈ " + fmtSize(plan.size), 96.dp)
                        InfoLine("Битрейт", (if (plan.hasVideo) "видео ${fmtBps(plan.vBps)} · " else "") + "звук ${fmtBps(plan.aBps)}", 96.dp)
                        InfoLine("Качество", qualityText(plan), 96.dp)
                        InfoLine("Разрешение", if (plan.hasVideo) "${plan.outW}×${plan.outH}" + if (plan.encode && scaleOn) " (16:9, с полосами)" else "" else "—", 96.dp)
                        Button({
                            job("Обработка файла") {
                                val chosen = tracks.filter { it.on }
                                if (chosen.isEmpty()) { status = "Выберите хотя бы одну дорожку"; progress = 0f; return@job }
                                if (plan.error != null) { status = plan.error; progress = 0f; return@job }
                                val vSel = chosen.filter { it.type == "video" }
                                val aSel2 = chosen.filter { it.type == "audio" }
                                val args = mutableListOf(bm.ffmpeg, "-hide_banner", "-y", "-i", input!!.absolutePath)
                                chosen.forEach { args += listOf("-map", "0:${it.index}") }
                                args += listOf("-c", "copy")
                                if (chosen.any { it.type == "subtitle" && it.codec == "mov_text" }) args += listOf("-c:s", "srt")
                                if (audioOn && aSel2.isNotEmpty()) {
                                    args += listOf("-c:a", "ac3", "-af", PRESETS[preset].third)
                                    aSel2.forEachIndexed { n, t ->
                                        val five = t.ch >= 6
                                        args += listOf("-b:a:$n", "${if (five) br51 else brSt}k")
                                        if (five) args += listOf("-ac:a:$n", "6")
                                    }
                                }
                                var x264 = false
                                if (plan.encode) {
                                    val n = vSel.indexOfFirst { it.codec !in listOf("mjpeg", "png", "bmp") }
                                    val encs = run(listOf(bm.ffmpeg, "-hide_banner", "-encoders"))
                                    val enc = listOf("libx264", "h264_mediacodec", "libx265", "mpeg4").firstOrNull { encs.contains(" $it ") } ?: "mpeg4"
                                    x264 = enc == "libx264"
                                    log("Кодер: $enc, видео ${plan.vBps / 1000} кбит/с")
                                    args += listOf("-c:v:$n", enc, "-b:v:$n", "${plan.vBps}", "-maxrate:v:$n", "${(plan.vBps * 1.5).toLong()}", "-bufsize:v:$n", "${plan.vBps * 2}")
                                    if (x264) args += listOf("-pix_fmt:v:$n", "yuv420p", "-preset:v:$n", SPEEDS[speed].second)
                                    if (scaleOn) args += listOf("-filter:v:$n", "scale=${plan.outW}:${plan.outH}:force_original_aspect_ratio=decrease,pad=${plan.outW}:${plan.outH}:(ow-iw)/2:(oh-ih)/2:black,setsar=1")
                                }
                                val out = outFile("edit")
                                args += out
                                val t0 = System.nanoTime()
                                run(args, track = true)
                                val el = (System.nanoTime() - t0) / 1e9
                                if (rs.exit == 0 && x264 && el > 20 && duration > 0) {
                                    val norm = duration / el * (plan.outW * plan.outH) / 2_073_600.0 * (plan.fps.coerceIn(24.0, 60.0) / 24.0)
                                    prefs.edit().putFloat("cal_$speed", norm.toFloat()).apply(); calTick++
                                }
                                finish(out)
                            }
                        }, enabled = !busy, modifier = Modifier.fillMaxWidth().height(52.dp), shape = RoundedCornerShape(16.dp)) { Text("Запустить обработку", fontWeight = FontWeight.SemiBold) }
                    }
                }
                Spacer(Modifier.height(8.dp))
            }

            // Нижняя панель: прогресс + выдвижной лог
            Surface(Modifier.fillMaxWidth(), color = MaterialTheme.colorScheme.surfaceContainerHigh,
                shape = RoundedCornerShape(topStart = 24.dp, topEnd = 24.dp), shadowElevation = 8.dp) {
                Column(Modifier.navigationBarsPadding().padding(horizontal = 16.dp, vertical = 6.dp)) {
                    Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).clickable { logOpen = !logOpen }.padding(vertical = 2.dp),
                        horizontalArrangement = Arrangement.Center, verticalAlignment = Alignment.CenterVertically) {
                        Icon(if (logOpen) Icons.Filled.KeyboardArrowDown else Icons.Filled.KeyboardArrowUp, contentDescription = "Лог")
                        Text("Лог", style = MaterialTheme.typography.labelLarge)
                    }
                    val p = progress
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(status, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Medium, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            if (speedTxt.isNotEmpty()) Text("скорость $speedTxt", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        if (p != null) Text("${(p * 100).toInt()}%", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                        if (busy && progress != null) TextButton(onClick = { rs.stopped = true; rs.proc?.destroy() }) { Text("Стоп") }
                    }
                    val bar = Modifier.fillMaxWidth().height(8.dp).clip(RoundedCornerShape(4.dp))
                    if (busy && p == null) LinearProgressIndicator(bar) else LinearProgressIndicator(progress = { p ?: 0f }, modifier = bar)
                    AnimatedVisibility(logOpen, enter = expandVertically(expandFrom = Alignment.Bottom) + fadeIn(), exit = shrinkVertically(shrinkTowards = Alignment.Bottom) + fadeOut()) {
                        val sc = rememberScrollState()
                        LaunchedEffect(logs.size) { sc.scrollTo(sc.maxValue) }
                        Box(Modifier.fillMaxWidth().padding(top = 10.dp, bottom = 6.dp).height(240.dp).clip(RoundedCornerShape(12.dp)).background(Color(0xFF101418)).verticalScroll(sc).padding(10.dp)) {
                            SelectionContainer { Text(logs.joinToString("\n"), fontFamily = FontFamily.Monospace, fontSize = 11.sp, color = Color(0xFFB8F5B8)) }
                        }
                    }
                    Spacer(Modifier.height(6.dp))
                }
            }
        }
    }
}

@Composable
fun AppTheme(content: @Composable () -> Unit) {
    val dark = isSystemInDarkTheme()
    val ctx = LocalContext.current
    val cs = when {
        Build.VERSION.SDK_INT >= 31 -> if (dark) dynamicDarkColorScheme(ctx) else dynamicLightColorScheme(ctx)
        dark -> darkColorScheme()
        else -> lightColorScheme()
    }
    MaterialTheme(colorScheme = cs, content = content)
}

@Composable
fun SectionCard(title: String, subtitle: String? = null, content: @Composable ColumnScope.() -> Unit) {
    Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(20.dp), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerHigh)) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text(title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
            if (subtitle != null) Text(subtitle, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            content()
        }
    }
}

@Composable
fun TrackRow(t: Track, onToggle: (Boolean) -> Unit) {
    val cs = MaterialTheme.colorScheme
    val (label, bg, fg) = when (t.type) {
        "video" -> Triple("ВИДЕО", cs.primaryContainer, cs.onPrimaryContainer)
        "audio" -> Triple("АУДИО", cs.tertiaryContainer, cs.onTertiaryContainer)
        "subtitle" -> Triple("СУБТ", cs.secondaryContainer, cs.onSecondaryContainer)
        else -> Triple(t.type.uppercase(), cs.surfaceVariant, cs.onSurfaceVariant)
    }
    Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).clickable { onToggle(!t.on) }.padding(vertical = 2.dp), verticalAlignment = Alignment.CenterVertically) {
        Checkbox(t.on, null)
        Spacer(Modifier.width(6.dp))
        Box(Modifier.clip(RoundedCornerShape(6.dp)).background(bg).padding(horizontal = 6.dp, vertical = 2.dp)) {
            Text(label, color = fg, fontSize = 10.sp, fontWeight = FontWeight.Bold)
        }
        Spacer(Modifier.width(10.dp))
        Column(Modifier.weight(1f)) {
            Text("#${t.index} ${t.codec.uppercase()}" + when (t.type) { "video" -> " · ${t.w}×${t.h} · ${fmtBps(t.bps)}"; "audio" -> " · ${chLabel(t.ch)} · ${fmtBps(t.bps)}"; else -> "" }, style = MaterialTheme.typography.bodyMedium, maxLines = 1, overflow = TextOverflow.Ellipsis)
            val sub = listOf(t.lang, t.title).filter { it.isNotBlank() }.joinToString(" · ")
            if (sub.isNotEmpty()) Text(sub, style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
    }
}

@Composable
fun InfoLine(label: String, value: String, w: Dp = 78.dp) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Text(label, Modifier.width(w), style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold)
        Text(value, style = MaterialTheme.typography.bodySmall, maxLines = 3, overflow = TextOverflow.Ellipsis)
    }
}

@Composable
fun ToggleCard(title: String, subtitle: String, checked: Boolean, onChecked: (Boolean) -> Unit, enabled: Boolean, content: @Composable ColumnScope.() -> Unit) {
    Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(20.dp), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerHigh)) {
        Column(Modifier.padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                    Text(subtitle, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                Switch(checked, onChecked, enabled = enabled)
            }
            AnimatedVisibility(checked) {
                Column(Modifier.padding(top = 10.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) { content() }
            }
        }
    }
}
