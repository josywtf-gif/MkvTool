package com.mkvtool

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.media.MediaExtractor
import android.media.MediaFormat
import android.media.MediaMetadataRetriever
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.OpenableColumns
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.KeyboardArrowUp
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalView
import androidx.core.view.WindowCompat
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.FileProvider
import kotlinx.coroutines.*
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

data class Track(val index: Int, val type: String, val codec: String, val lang: String, val title: String,
                 val w: Int, val h: Int, val ch: Int, val bps: Long, val fps: Double, val on: Boolean = true)

// Рассчитываем средний битрейт видеопотока по фактическому размеру файла.
// format.bit_rate намеренно не используется: это общий битрейт контейнера.
fun applyCalculatedVideoBitrate(tracks: List<Track>, fileSizeBytes: Long, durationSeconds: Double): List<Track> {
    if (fileSizeBytes <= 0L || durationSeconds <= 0.0) return tracks
    val videoTracks = tracks.filter { it.type == "video" }
    if (videoTracks.isEmpty()) return tracks
    val audioBps = tracks.asSequence()
        .filter { it.type == "audio" }
        .sumOf { it.bps.coerceAtLeast(0L) }
    val totalBps = (fileSizeBytes.toDouble() * 8.0 / durationSeconds).toLong()
    val videoBps = (totalBps - audioBps).coerceAtLeast(0L)
    // Формула даёт суммарный битрейт всех видеопотоков. Для обычного MKV
    // с одной видеодорожкой это и есть её битрейт.
    val primaryVideoIndex = videoTracks.first().index
    return tracks.map { track ->
        if (track.type == "video" && track.index == primaryVideoIndex) track.copy(bps = videoBps)
        else if (track.type == "video") track.copy(bps = 0L)
        else track
    }
}
class SavedProject(val file: File, val duration: Double, val tracks: List<Track>)
fun tracksToJson(t: List<Track>): String = JSONArray().apply {
    t.forEach { put(JSONObject().put("i", it.index).put("t", it.type).put("c", it.codec).put("l", it.lang).put("n", it.title)
        .put("w", it.w).put("h", it.h).put("ch", it.ch).put("b", it.bps).put("f", it.fps).put("on", it.on)) }
}.toString()
fun tracksFromJson(s: String): List<Track> {
    val a = JSONArray(s)
    return (0 until a.length()).map { val o = a.getJSONObject(it)
        Track(o.getInt("i"), o.getString("t"), o.getString("c"), o.getString("l"), o.getString("n"), o.getInt("w"), o.getInt("h"), o.getInt("ch"), o.getLong("b"), o.getDouble("f"), o.getBoolean("on")) }
}
class RunState { @Volatile var exit = 0; @Volatile var stopped = false; @Volatile var proc: Process? = null; @Volatile var fg = false; @Volatile var lastNotif = 0L }

private val TIME_RE = Regex("time=(\\d+):(\\d+):(\\d+(?:\\.\\d+)?)")
private val PROG_KEY_RE = Regex("^(frame|fps|stream_\\d+_\\d+_q|bitrate|total_size|out_time_us|out_time_ms|out_time|dup_frames|drop_frames|speed|progress)=")
private val SPEED_RE = Regex("speed=\\s*([\\d.]+)x")

fun fmtDur(sec: Double): String {
    val s = sec.toLong(); return "%d:%02d:%02d".format(s / 3600, s % 3600 / 60, s % 60)
}
fun fmtBps(b: Long): String = when { b <= 0 -> "—"; b >= 1_000_000 -> "%.1f Мбит/с".format(b / 1e6); else -> "%.0f кбит/с".format(b / 1e3) }
fun chLabel(n: Int): String = when (n) { 1 -> "1.0"; 2 -> "2.0"; 6 -> "5.1"; 8 -> "7.1"; else -> "$n кан." }
val PRESETS = listOf(
    Triple("Мягкий", "Деликатное выравнивание: громкое чуть тише, диалоги разборчивее, динамика сохраняется.", "acompressor=threshold=-20dB:ratio=2.5:attack=20:release=300:makeup=2dB:knee=6dB"),
    Triple("Средний", "Заметнее: взрывы не бьют по ушам, голоса выходят вперёд.", "acompressor=threshold=-22dB:ratio=4:attack=15:release=250:makeup=4dB:knee=4dB"),
    Triple("Сильный", "Эффект «телевизора»: почти одна громкость, для ночного просмотра.", "acompressor=threshold=-24dB:ratio=6:attack=10:release=200:makeup=6dB:knee=2dB")
)
fun audioOutBps(sel: List<Track>, on: Boolean, br51: Int, brSt: Int): Long =
    sel.filter { it.type == "audio" }.sumOf { if (on) (if (it.ch >= 6) br51 else brSt) * 1000L else if (it.bps > 0) it.bps else 192_000L }
fun videoTargetBps(gb: Double, duration: Double, audioBps: Long): Long =
    // Поле ввода задано в ГБ (GiB), поэтому переводим в байты через 1024^3.
    // Затем вычитаем суммарный битрейт выбранных аудиодорожек и небольшой резерв.
    ((gb * 1024.0 * 1024.0 * 1024.0 * 8.0 / duration) - audioBps - 50_000L)
        .toLong().coerceAtLeast(100_000L)
fun parseFps(s: String): Double {
    val p = s.split("/")
    val d = p.getOrNull(1)?.toDoubleOrNull() ?: 0.0
    return if (p.size == 2 && d != 0.0) (p[0].toDoubleOrNull() ?: 24.0) / d else s.toDoubleOrNull()?.takeIf { it > 0 } ?: 24.0
}
fun fmtTime(sec: Double): String = when {
    sec < 60 -> "< 1 мин"
    sec < 3600 -> "~${(sec / 60).toInt()} мин"
    else -> "~${(sec / 3600).toInt()} ч ${"%02d".format((sec % 3600 / 60).toInt())} мин"
}
val SPEEDS = listOf(Triple("Быстро", "veryfast", 1.6), Triple("Баланс", "medium", 0.7), Triple("Качество", "slow", 0.35))
val SPEED_NOTES = listOf("Быстрее всего, но при том же размере качество картинки ниже.", "Золотая середина скорости и качества.", "Лучшее качество при том же размере, но обработка очень долгая.")
fun encSpeed(idx: Int, pixels: Int, fps: Double, cal: FloatArray): Double {
    val base = if (cal[idx] > 0) cal[idx].toDouble() else SPEEDS[idx].third
    return base * 2_073_600.0 / pixels.coerceAtLeast(1) * (24.0 / fps.coerceIn(24.0, 60.0))
}
data class Plan(val encode: Boolean, val outW: Int, val outH: Int, val fps: Double, val vBps: Long, val aBps: Long,
                val size: Long, val time: Double, val bpp: Double, val error: String?, val hasVideo: Boolean,
                val origV: Long, val origA: Long, val origW: Int, val origH: Int, val codec: String)
fun buildPlan(tracks: List<Track>, fileLen: Long, duration: Double, videoOn: Boolean, gb: Double?, scaleOn: Boolean, scaleH: Int,
              audioOn: Boolean, br51: Int, brSt: Int, speed: Int, cal: FloatArray, forceH264: Boolean = false): Plan {
    val sel = tracks.filter { it.on }
    val mv = sel.firstOrNull { it.type == "video" && it.w > 0 && it.codec !in listOf("mjpeg", "png", "bmp") }
    val encode = mv != null && (videoOn || scaleOn || forceH264)
    val outW = if (encode && scaleOn) scaleH * 16 / 9 else mv?.w ?: 0
    val outH = if (encode && scaleOn) scaleH else mv?.h ?: 0
    val fps = mv?.fps ?: 24.0
    val aSelOrig = sel.filter { it.type == "audio" }.sumOf { if (it.bps > 0) it.bps else 192_000L }
    val aBps = audioOutBps(sel, audioOn, br51, brSt)
    val dur = maxOf(duration, 1.0)
    val origV = if (mv == null) 0L else if (mv.bps > 0) mv.bps else maxOf(500_000L, (fileLen * 8 / dur).toLong() - aSelOrig)
    var err: String? = null
    val vBps: Long
    val size: Long
    if (encode && videoOn) {
        if (gb == null) err = "Введите размер числом" else if (duration <= 0) err = "Неизвестна длительность файла"
        vBps = if (gb != null && duration > 0) videoTargetBps(gb, duration, aBps) else origV
        val minBps = if (outH >= 1000) 1_500_000L else 800_000L
        if (gb != null && gb > 0 && vBps < minBps) err = "Слишком маленький размер файла. Качество будет испорчено. Увеличьте размер"
        size = ((vBps + aBps + 50_000L) * dur / 8.0).toLong()
    } else {
        vBps = origV
        val removed = tracks.filter { !it.on }.sumOf { it.bps } * dur / 8
        val audioDelta = if (audioOn) (aBps - aSelOrig) * dur / 8 else 0.0
        size = (fileLen - removed + audioDelta).toLong().coerceAtLeast(0)
    }
    val time = if (encode) dur / encSpeed(speed, outW * outH, fps, cal) else fileLen / 60e6 + (if (audioOn) dur / 40 else 0.0)
    val bpp = if (encode && outW > 0) vBps / (outW.toDouble() * outH * fps.coerceAtLeast(1.0)) else 0.0
    return Plan(encode, outW, outH, fps, vBps, aBps, size, time, bpp, err, mv != null, origV, aSelOrig, mv?.w ?: 0, mv?.h ?: 0, mv?.codec ?: "")
}

// ── Оценка качества по битрейту ──
class Level(val name: String, val color: Color)
val LV_BAD = Level("Плохо", Color(0xFFE5484D))     // красный
val LV_MID = Level("Средне", Color(0xFFF76B15))    // тёмно-оранжевый
val LV_GOOD = Level("Хорошо", Color(0xFFFFA01C))   // оранжевый
val LV_TOP = Level("Отлично", Color(0xFF30A46C))   // зелёный
fun codecEff(c: String): Double = when (c.lowercase()) { "hevc", "h265" -> 1.6; "av1" -> 2.0; "vp9" -> 1.4; else -> 1.0 }
fun bitrateLevel(bps: Long, w: Int, h: Int, fps: Double, codec: String): Level? {
    if (bps <= 0 || w <= 0 || h <= 0) return null
    val bpp = bps * codecEff(codec) / (w.toDouble() * h * fps.coerceAtLeast(1.0))
    return when { bpp < 0.035 -> LV_BAD; bpp < 0.06 -> LV_MID; bpp < 0.10 -> LV_GOOD; else -> LV_TOP }
}
/** Оценка битрейта звука с учётом числа каналов и кодека; lossless — всегда «Отлично». */
fun audioLevel(bps: Long, ch: Int, codec: String): Level? {
    val c = codec.lowercase()
    if (c == "truehd" || c == "mlp" || c == "flac" || c == "alac" || c.startsWith("pcm")) return LV_TOP
    if (bps <= 0) return null
    val eff = when (c) { "aac", "opus", "vorbis" -> 1.5; "eac3" -> 1.3; else -> 1.0 }
    val v = bps * eff
    val (t1, t2, t3) = when {
        ch >= 6 -> Triple(256_000.0, 384_000.0, 512_000.0)
        ch == 1 -> Triple(48_000.0, 80_000.0, 128_000.0)
        else -> Triple(96_000.0, 160_000.0, 256_000.0)
    }
    return when { v < t1 -> LV_BAD; v < t2 -> LV_MID; v < t3 -> LV_GOOD; else -> LV_TOP }
}
fun levelText(text: String, lv: Level?): AnnotatedString = buildAnnotatedString {
    append(text)
    if (lv != null) { append("  "); withStyle(SpanStyle(color = lv.color, fontWeight = FontWeight.Bold)) { append(lv.name) } }
}
fun fmtSize(b: Long): String = if (b >= 1L shl 30) "%.2f ГБ".format(b / 1073741824.0) else "%.0f МБ".format(b / 1048576.0)

class MainActivity : ComponentActivity() {
    private val sp by lazy { getSharedPreferences("settings", MODE_PRIVATE) }
    private var themeMode by mutableStateOf("system")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        themeMode = sp.getString("theme", "system") ?: "system"
        setContent { AppTheme(themeMode) { Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) { App() } } }
    }

    @OptIn(ExperimentalMaterial3Api::class)
    @Composable
    fun App() {
        val scope = rememberCoroutineScope()
        val pj = remember { getSharedPreferences("project", MODE_PRIVATE) }
        val bm = remember { BinaryManager(this) }
        val rs = remember { RunState() }
        val tracks = remember { mutableStateListOf<Track>() }
        val logs = remember { mutableStateListOf<String>() }
        var input by remember { mutableStateOf<File?>(null) }
        var duration by remember { mutableStateOf(0.0) }
        var busy by remember { mutableStateOf(false) }
        var status by remember { mutableStateOf("Подготовка…") }
        var progress by remember { mutableStateOf<Float?>(null) }
        var speedTxt by remember { mutableStateOf("") }
        var actualOutputBitrate by remember { mutableStateOf<Long?>(null) }
        var logOpen by remember { mutableStateOf(false) }
        var errorLogOpen by remember { mutableStateOf(false) }
        var failedCommand by remember { mutableStateOf("") }
        val clipboard = LocalClipboardManager.current
        var gb by remember { mutableStateOf(pj.getString("gb", "0") ?: "0") }          // 0 = сжатие по размеру выключено
        var comp by remember { mutableStateOf(pj.getInt("comp", 0)) }          // компрессор: 0 не сжимать, 1 мягко, 2 средне, 3 сильно
        var videoOpen by remember { mutableStateOf(false) } // вкладка «Обработка видео»
        var audioOpen by remember { mutableStateOf(false) } // вкладка «Сжатие звука»
        var tracksOpen by remember { mutableStateOf(false) } // вкладка «Дорожки» (скрыта)
        var hardware by remember { mutableStateOf(pj.getBoolean("hardware", false)) }
        var convertH264 by remember { mutableStateOf(false) }
        var br51 by remember { mutableStateOf(pj.getInt("br51", 448)) }
        var brSt by remember { mutableStateOf(pj.getInt("brSt", 192)) }
        var speed by remember { mutableStateOf(pj.getInt("speed", 1)) }
        var saved by remember { mutableStateOf<SavedProject?>(null) }
        var pendingUri by remember { mutableStateOf<Uri?>(null) }
        var pendingName by remember { mutableStateOf<String?>(null) }
        var pendingSize by remember { mutableStateOf(0L) }
        var infoTracks by remember { mutableStateOf<List<Track>>(emptyList()) }
        var infoDuration by remember { mutableStateOf(0.0) }
        var infoDialog by remember { mutableStateOf(false) }
        var showSettings by remember { mutableStateOf(false) }
        var confirmOpen by remember { mutableStateOf(false) }
        var exitConfirmOpen by remember { mutableStateOf(false) }
        var calTick by remember { mutableStateOf(0) }
        var updateInfo by remember { mutableStateOf<Pair<Int, String>?>(null) }
        val prefs = remember { getSharedPreferences("cal", MODE_PRIVATE) }
        val cal = remember(calTick) { FloatArray(3) { prefs.getFloat("cal_$it", 0f) } }

        // Сохранение настроек и проекта (дорожки), чтобы после перезапуска можно было вернуться
        LaunchedEffect(gb, comp, hardware, br51, brSt, speed) {
            pj.edit().putString("gb", gb).putInt("comp", comp).putBoolean("hardware", hardware).putInt("br51", br51).putInt("brSt", brSt).putInt("speed", speed).apply()
        }
        val trackSnap = tracks.toList()
        LaunchedEffect(trackSnap, input, duration) {
            val f = input
            if (f != null && trackSnap.isNotEmpty())
                pj.edit().putString("file", f.name).putString("dur", duration.toString()).putString("tracks", tracksToJson(trackSnap)).apply()
        }
        fun forgetProject() { pj.edit().remove("file").remove("dur").remove("tracks").apply(); saved = null; pendingUri = null; pendingName = null; pendingSize = 0L }
        fun restoreProject() {
            val sv = saved ?: return
            tracks.clear(); tracks.addAll(sv.tracks); input = sv.file; duration = sv.duration; saved = null; tracksOpen = false
            status = "Проект восстановлен — выберите действие"; progress = 0f
        }

        fun leaveProject() {
            val f = input ?: return
            saved = SavedProject(f, duration, tracks.toList())
            tracks.clear(); input = null; duration = 0.0
            status = "Есть сохранённый проект"; progress = 0f
        }

        fun log(s: String) { logs.add(s) }

        suspend fun run(cmd: List<String>, track: Boolean = false): String = withContext(Dispatchers.IO) {
            withContext(Dispatchers.Main) { log("$ " + cmd.joinToString(" ")) }
            val sb = StringBuilder(); var code = -1
            val commandText = cmd.joinToString(" ")
            try {
                val p = ProcessBuilder(cmd).redirectErrorStream(true).start(); rs.proc = p
                val rd = p.inputStream.bufferedReader()
                // ffmpeg выводит строки прогресса через \r (без \n), поэтому readLine() не отдаёт их
                // до конца работы. Читаем посимвольно и режем по \r и по \n.
                val line = StringBuilder()
                var lastT = 0.0
                suspend fun handle(l: String) {
                    if (l.isBlank()) return
                    val isProg = l.contains("time=") || PROG_KEY_RE.containsMatchIn(l)
                    if (!isProg) { sb.appendLine(l); withContext(Dispatchers.Main) { log(l) } }
                    if (!track || !isProg) return
                    val m = TIME_RE.find(l)
                    if (m != null && duration > 0) {
                        val t = m.groupValues[1].toDouble() * 3600 + m.groupValues[2].toDouble() * 60 + m.groupValues[3].toDouble()
                        lastT = t
                        val frac = (t / duration).coerceIn(0.0, 1.0)
                        progress = frac.toFloat()
                        val now = System.currentTimeMillis()
                        if (rs.fg && now - rs.lastNotif > 1500) { rs.lastNotif = now; Notif.progress(this@MainActivity, status, (frac * 100).toInt()) }
                    }
                    val spd = SPEED_RE.find(l)?.groupValues?.get(1)?.toDoubleOrNull()
                    if (spd != null && spd > 0.0 && duration > 0) {
                        val left = (duration - lastT).coerceAtLeast(0.0) / spd
                        speedTxt = "${"%.2f".format(spd)}× · осталось ${fmtTime(left).replace("~", "≈ ")}"
                    }
                }
                while (true) {
                    val ch = rd.read()
                    if (ch < 0) break
                    if (ch == '\r'.code || ch == '\n'.code) { handle(line.toString()); line.setLength(0) }
                    else line.append(ch.toChar())
                }
                if (line.isNotEmpty()) handle(line.toString())
                code = p.waitFor()
            } catch (e: Exception) { withContext(Dispatchers.Main) { log("ERR: ${e.message}") } }
            rs.proc = null; rs.exit = code
            withContext(Dispatchers.Main) {
                log("exit=$code")
                if (code != 0) failedCommand = commandText
            }
            sb.toString()
        }
        fun outDir(): File = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS).apply { mkdirs() }
        fun outFile(suffix: String): String {
            val d = outDir(); val base = input!!.nameWithoutExtension
            var f = File(d, "${base}_$suffix.mkv"); var i = 1
            while (f.exists()) { f = File(d, "${base}_$suffix ($i).mkv"); i++ }
            return f.absolutePath
        }
        fun startWork() {
            val i = Intent(this, WorkService::class.java).setAction(WorkService.ACTION_START)
            if (Build.VERSION.SDK_INT >= 26) startForegroundService(i) else startService(i)
        }
        fun job(title: String, longRun: Boolean = false, block: suspend () -> Unit) {
            if (busy) return
            scope.launch {
                busy = true; rs.stopped = false; status = title; progress = null; speedTxt = ""
                if (longRun) { rs.fg = true; rs.lastNotif = 0L; startWork() }
                try {
                    block()
                } catch (e: Exception) {
                    log("ERR: ${e.message}")
                    status = "Ошибка: ${e.message}"
                    progress = 0f
                    if (longRun) Notif.done(this@MainActivity, "Ошибка", e.message ?: "")
                } finally {
                    // Всегда освобождаем CPU WakeLock после завершения/ошибки/отмены.
                    if (longRun) {
                        rs.fg = false
                        stopService(Intent(this@MainActivity, WorkService::class.java))
                    }
                    busy = false
                }
            }
        }

        fun stopProcess() {
            val p = rs.proc ?: return
            rs.stopped = true; status = "Останавливаю…"
            scope.launch(Dispatchers.IO) {
                val pid = runCatching { (p.javaClass.getMethod("pid").invoke(p) as Number).toInt() }.getOrNull()
                    ?: runCatching { p.javaClass.getDeclaredField("pid").apply { isAccessible = true }.getInt(p) }.getOrNull()
                var sent = false
                if (pid != null) sent = runCatching { Runtime.getRuntime().exec(arrayOf("kill", "-INT", pid.toString())).waitFor() == 0 }.getOrDefault(false)
                if (!sent) runCatching { p.outputStream.write("q\n".toByteArray()); p.outputStream.flush() }
                withContext(Dispatchers.Main) { log(if (sent) "SIGINT отправлен, ffmpeg завершает файл…" else "Команда q отправлена, ffmpeg завершает файл…") }
                delay(15_000)
                val alive = try { p.exitValue(); false } catch (e: IllegalThreadStateException) { true }
                if (alive) { p.destroy(); withContext(Dispatchers.Main) { log("Принудительное завершение") } }
            }
        }
        fun clearFile() = job("Очистка кеша") {
            withContext(Dispatchers.IO) { cacheDir.listFiles()?.forEach { it.deleteRecursively() } }
            forgetProject()
            tracks.clear(); input = null; duration = 0.0; pendingUri = null; pendingName = null; pendingSize = 0L
            status = "Файл убран, кеш очищен"; progress = 0f
        }

        val permLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {}
        fun storageOk(): Boolean {
            val ok = if (Build.VERSION.SDK_INT >= 30) Environment.isExternalStorageManager()
                     else checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) == android.content.pm.PackageManager.PERMISSION_GRANTED
            if (!ok) {
                status = "Нужен доступ к файлам — разреши и запусти снова"; progress = 0f
                if (Build.VERSION.SDK_INT >= 30) runCatching { startActivity(Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION, Uri.parse("package:$packageName"))) }
                else permLauncher.launch(arrayOf(Manifest.permission.WRITE_EXTERNAL_STORAGE))
            }
            return ok
        }
        LaunchedEffect(Unit) {
            permLauncher.launch(buildList { add(Manifest.permission.READ_EXTERNAL_STORAGE); add(Manifest.permission.WRITE_EXTERNAL_STORAGE); if (Build.VERSION.SDK_INT >= 33) add("android.permission.POST_NOTIFICATIONS") }.toTypedArray())
            if (Build.VERSION.SDK_INT >= 30 && !Environment.isExternalStorageManager()) {
                runCatching { startActivity(Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION, Uri.parse("package:$packageName"))) }
            }
            runCatching {
                val name = pj.getString("file", null); val js = pj.getString("tracks", null)
                if (name != null && js != null) {
                    val f = File(cacheDir, name)
                    if (f.exists() && f.length() > 0) saved = SavedProject(f, pj.getString("dur", "0")?.toDoubleOrNull() ?: 0.0, tracksFromJson(js))
                    else forgetProject()
                }
            }
            if (!bm.ready) { busy = true; status = "Первый запуск: загрузка ffmpeg…"; progress = null }
            val err = withContext(Dispatchers.IO) {
                try { bm.ensure { s -> scope.launch(Dispatchers.Main) { log(s) } }; null } catch (e: Exception) { e.message ?: "unknown" }
            }
            busy = false
            if (err != null) { status = "Ошибка загрузки ffmpeg: $err"; progress = 0f; log("Ошибка бинарников: $err") }
            else { status = if (saved != null) "Есть сохранённый проект" else "Выберите файл"; progress = 0f }
        }

        val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
            if (uri == null) return@rememberLauncherForActivityResult
            // Сохраняем разрешение SAF и держим исходный URI: выбор файла не копирует его в кеш.
            runCatching { contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) }
            var name = "video.mkv"
            var size = 0L
            contentResolver.query(uri, null, null, null, null)?.use { c ->
                if (c.moveToFirst()) {
                    val ni = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                    if (ni >= 0) name = c.getString(ni) ?: name
                    val si = c.getColumnIndex(OpenableColumns.SIZE)
                    if (si >= 0 && !c.isNull(si)) size = c.getLong(si)
                }
            }
            // При выборе другого файла возвращаем текущий проект в список, не удаляя его кеш.
            if (input != null) leaveProject()
            actualOutputBitrate = null
            pendingUri = uri
            pendingName = name
            pendingSize = size
            infoDialog = false
            status = "Файл добавлен — выберите «Посмотреть» или «Создать проект»"
            progress = 0f
        }

        suspend fun probeFile(f: File): Pair<Double, List<Track>> = withContext(Dispatchers.IO) {
            // Первый проход получает метаданные и длительность контейнера.
            val metaCmd = listOf(
                bm.ffprobe, "-v", "error", "-print_format", "json",
                "-show_streams", "-show_format", f.absolutePath
            )
            val metaProcess = ProcessBuilder(metaCmd).redirectErrorStream(true).start()
            val metaText = metaProcess.inputStream.bufferedReader().use { it.readText() }
            val metaExit = metaProcess.waitFor()
            if (metaExit != 0) error("FFprobe не смог прочитать файл: ${metaText.take(1000)}")
            val jsonStart = metaText.indexOf('{')
            if (jsonStart < 0) error("FFprobe не вернул информацию о файле")
            val j = JSONObject(metaText.substring(jsonStart))
            val format = j.optJSONObject("format")
            val dur = format?.optString("duration")?.toDoubleOrNull() ?: 0.0
            val streams = j.optJSONArray("streams") ?: JSONArray()
            val parsed = mutableListOf<Track>()
            for (k in 0 until streams.length()) {
                val o = streams.getJSONObject(k)
                val tags = o.optJSONObject("tags")
                var metadataBps = if (o.optString("codec_type") == "audio") o.optString("bit_rate").toLongOrNull() ?: 0L else 0L
                if (metadataBps <= 0L && o.optString("codec_type") == "audio" && tags != null) {
                    val key = tags.keys().asSequence().firstOrNull { it.equals("BPS", true) || it.startsWith("BPS-", true) }
                    if (key != null) metadataBps = tags.optString(key).toLongOrNull() ?: 0L
                }
                val fpsText = o.optString("avg_frame_rate").takeIf { it.isNotBlank() && it != "0/0" }
                    ?: o.optString("r_frame_rate", "24/1")
                val channels = o.optInt("channels", 0).let { count ->
                    if (count > 0) count else when (o.optString("channel_layout")) {
                        "mono" -> 1; "stereo" -> 2; "5.1", "5.1(side)" -> 6; "7.1" -> 8; else -> 0
                    }
                }
                parsed.add(Track(
                    o.optInt("index", k), o.optString("codec_type", "data"), o.optString("codec_name", "unknown"),
                    tags?.optString("language")?.takeIf { it.isNotBlank() } ?: "und",
                    tags?.optString("title") ?: "", o.optInt("width", 0), o.optInt("height", 0),
                    channels, metadataBps, parseFps(fpsText)
                ))
            }

            // File.length() возвращает размер в байтах. Не используем format.bit_rate,
            // поскольку это общий битрейт контейнера, а не видеопотока.
            val resultTracks = applyCalculatedVideoBitrate(parsed, f.length(), dur)
            dur to resultTracks
        }

        suspend fun probeUri(uri: Uri): Pair<Double, List<Track>> = withContext(Dispatchers.IO) {
            // FFprobe читает исходный SAF-документ через stdin: файл не копируется в кеш
            // и остаётся нетронутым. В отличие от MediaExtractor это поддерживает MKV,
            // включая дорожки/кодеки, которые Android framework может не распознать.
            val cmd = listOf(
                bm.ffprobe, "-v", "error", "-probesize", "10M", "-analyzeduration", "10M",
                "-print_format", "json", "-show_streams", "-show_format", "-i", "pipe:0"
            )
            val process = ProcessBuilder(cmd).start()
            val stderr = StringBuilder()
            val stderrJob = CoroutineScope(Dispatchers.IO).launch {
                process.errorStream.bufferedReader().useLines { lines -> lines.forEach { line ->
                    synchronized(stderr) { stderr.appendLine(line) }
                } }
            }
            val writerJob = async(Dispatchers.IO) {
                try {
                    contentResolver.openInputStream(uri)?.use { source ->
                        process.outputStream.use { target -> source.copyTo(target, 1024 * 1024) }
                    } ?: error("Не удалось открыть выбранный файл")
                } catch (e: java.io.IOException) {
                    // FFprobe иногда закрывает stdin раньше, когда уже получил достаточно
                    // данных для анализа. Это не ошибка само по себе: итог определяет exit code.
                    val message = e.message.orEmpty()
                    if (!message.contains("EPIPE", ignoreCase = true) &&
                        !message.contains("Broken pipe", ignoreCase = true) &&
                        !message.contains("Pipe closed", ignoreCase = true)) {
                        throw e
                    } else {
                        // Ветка catch используется как выражение внутри async; явно возвращаем Unit.
                        Unit
                    }
                } catch (e: Exception) {
                    runCatching { process.outputStream.close() }
                    throw e
                }
            }
            // Сначала дочитываем stdout и дожидаемся завершения FFprobe, затем проверяем
            // результат передачи файла. Так успешный анализ не будет ошибочно падать из-за EPIPE.
            val output = process.inputStream.bufferedReader().use { it.readText() }
            val exit = process.waitFor()
            writerJob.await()
            stderrJob.join()
            if (exit != 0) error("FFprobe не смог прочитать исходный файл (код $exit). ${stderr.toString().take(1200)}")
            val jsonStart = output.indexOf('{')
            if (jsonStart < 0) error("FFprobe не вернул информацию о файле. ${stderr.toString().take(1200)}")
            val root = JSONObject(output.substring(jsonStart))
            val format = root.optJSONObject("format")
            val dur = format?.optString("duration")?.toDoubleOrNull() ?: 0.0
            val streams = root.optJSONArray("streams") ?: JSONArray()
            val parsed = mutableListOf<Track>()
            for (k in 0 until streams.length()) {
                val o = streams.getJSONObject(k)
                val tags = o.optJSONObject("tags")
                val type = o.optString("codec_type", "data")
                val codec = o.optString("codec_name", "unknown")
                var bps = if (type == "audio") o.optString("bit_rate").toLongOrNull() ?: 0L else 0L
                if (bps <= 0L && type == "audio" && tags != null) {
                    val key = tags.keys().asSequence().firstOrNull { it.equals("BPS", true) || it.startsWith("BPS-", true) }
                    if (key != null) bps = tags.optString(key).toLongOrNull() ?: 0L
                }
                val fpsText = o.optString("avg_frame_rate").takeIf { it.isNotBlank() && it != "0/0" }
                    ?: o.optString("r_frame_rate", "24/1")
                val channels = o.optInt("channels", 0).let { count ->
                    if (count > 0) count else when (o.optString("channel_layout")) {
                        "mono" -> 1; "stereo" -> 2; "5.1", "5.1(side)" -> 6; "7.1" -> 8; else -> 0
                    }
                }
                parsed.add(Track(
                    o.optInt("index", k), type, codec,
                    tags?.optString("language")?.takeIf { it.isNotBlank() } ?: "und",
                    tags?.optString("title") ?: "", o.optInt("width", 0), o.optInt("height", 0),
                    channels, bps, parseFps(fpsText)
                ))
            }
            // SIZE от ContentResolver и format.size FFprobe — оба значения в байтах.
            // Не используем format.bit_rate: он относится ко всему контейнеру.
            val sourceSize = runCatching {
                contentResolver.query(uri, arrayOf(OpenableColumns.SIZE), null, null, null)?.use { cursor ->
                    if (cursor.moveToFirst() && !cursor.isNull(0)) cursor.getLong(0) else 0L
                } ?: 0L
            }.getOrDefault(0L).takeIf { it > 0L }
                ?: (format?.optString("size")?.toLongOrNull() ?: 0L)
            val resultTracks = applyCalculatedVideoBitrate(parsed, sourceSize, dur)
            dur to resultTracks
        }

        suspend fun finish(path: String) {
            speedTxt = ""
            val f = File(path)
            if (rs.exit == 0) {
                // Считываем длительность именно готового файла и считаем средний битрейт
                // по его фактическому размеру. Это учитывает контейнер, звук и все дорожки.
                actualOutputBitrate = runCatching {
                    val (outputDuration, _) = probeFile(f)
                    if (outputDuration > 0.0 && f.length() > 0L) (f.length() * 8.0 / outputDuration).toLong() else null
                }.getOrNull()
                if (actualOutputBitrate == null) log("Не удалось измерить битрейт результата через FFprobe; доступен расчёт по размеру и длительности")
                else log("Фактический средний битрейт результата: ${fmtBps(actualOutputBitrate!!)}")
                status = "Готово · ${f.name}"; progress = 1f; log("Сохранено: $path")
                Notif.done(this, "Обработка завершена", "Размер ${fmtSize(f.length())}" + (actualOutputBitrate?.let { " · битрейт ${fmtBps(it)}" } ?: "") + " · ${f.name}")
            } else if (rs.stopped) {
                if (f.exists() && f.length() > 0) { status = "Остановлено · частичный файл сохранён"; log("Частичный файл: $path") }
                else { f.delete(); status = "Остановлено" }
                progress = 0f
                Notif.done(this, "Обработка остановлена", status)
            } else {
                f.delete(); status = "Ошибка обработки (код ${rs.exit})"; progress = 0f
                errorLogOpen = true
                log("ОШИБКА ОБРАБОТКИ. Код возврата: ${rs.exit}")
                Notif.done(this, "Ошибка обработки", "Откройте окно лога для копирования подробностей")
            }
        }

        suspend fun copyUriToCache(uri: Uri, displayName: String, sizeHint: Long): File {
            val safeName = displayName.substringAfterLast('/').replace(Regex("[^\\p{L}\\p{N}._ -]"), "_").ifBlank { "video.mkv" }
            var target = File(cacheDir, safeName)
            var n = 1
            while (target.exists()) {
                val ext = target.extension
                val base = target.nameWithoutExtension
                target = File(cacheDir, "$base ($n)" + if (ext.isNotBlank()) ".$ext" else "")
                n++
            }
            try {
                withContext(Dispatchers.IO) {
                    val descriptorLength = runCatching {
                        contentResolver.openAssetFileDescriptor(uri, "r")?.use { it.length } ?: -1L
                    }.getOrDefault(-1L)
                    val total = sizeHint.takeIf { it > 0L } ?: descriptorLength.takeIf { it > 0L } ?: 0L
                    val input = contentResolver.openInputStream(uri) ?: error("Не удалось открыть выбранный файл")
                    input.use { source ->
                        target.outputStream().buffered().use { output ->
                            val buffer = ByteArray(1024 * 1024)
                            var copied = 0L
                            var lastUpdate = 0L
                            while (true) {
                                val count = source.read(buffer)
                                if (count < 0) break
                                output.write(buffer, 0, count)
                                copied += count
                                val now = System.currentTimeMillis()
                                if (now - lastUpdate >= 400L) {
                                    lastUpdate = now
                                    val fraction = if (total > 0L) (copied.toDouble() / total).coerceIn(0.0, 0.99).toFloat() else null
                                    withContext(Dispatchers.Main) {
                                        progress = fraction
                                        status = if (fraction != null) "Копирование в кеш" else "Копирование в кеш · ${fmtSize(copied)}"
                                        if (rs.fg) {
                                            if (fraction != null) Notif.progress(this@MainActivity, status, (fraction * 100).toInt())
                                            else Notif.indeterminate(this@MainActivity, status)
                                        }
                                    }
                                }
                            }
                            output.flush()
                            withContext(Dispatchers.Main) {
                                progress = 0.99f
                                status = "Анализ дорожек…"
                                if (rs.fg) Notif.progress(this@MainActivity, status, 99)
                            }
                        }
                    }
                }
            } catch (e: Exception) {
                target.delete()
                throw e
            }
            return target
        }

        fun createPendingProject() {
            val uri = pendingUri ?: return
            val name = pendingName ?: "video.mkv"
            val size = pendingSize
            job("Создание проекта", longRun = true) {
                val f = copyUriToCache(uri, name, size)
                val (dur, parsed) = probeFile(f)
                duration = dur; tracks.clear(); tracks.addAll(parsed); input = f
                gb = "0"; comp = 0; convertH264 = false; tracksOpen = false; videoOpen = false; audioOpen = false // новый проект: никакие преобразования по умолчанию не включены
                pendingUri = null; pendingName = null; pendingSize = 0L
                status = "Проект создан — выберите дорожки и действия"; progress = 1f
                Notif.done(this@MainActivity, "Проект создан", "${f.name} · ${fmtSize(f.length())}")
            }
        }
        fun checkPendingInfo() {
            val uri = pendingUri ?: return
            job("Чтение информации") {
                val (dur, parsed) = probeUri(uri)
                infoDuration = dur; infoTracks = parsed; infoDialog = true
                status = "Информация о файле получена (оригинал не изменён)"; progress = 0f
            }
        }

        fun installApk(apk: File) {
            if (Build.VERSION.SDK_INT >= 26 && !packageManager.canRequestPackageInstalls()) {
                status = "Разреши установку и нажми «Обновить» ещё раз"; progress = 0f
                startActivity(Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:$packageName")))
            } else {
                status = "Установка…"; progress = 0f
                startActivity(Intent(Intent.ACTION_VIEW).apply {
                    setDataAndType(FileProvider.getUriForFile(this@MainActivity, "$packageName.fp", apk), "application/vnd.android.package-archive")
                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
                })
            }
        }
        fun downloadUpdate(tag: Int, url: String) = job("Скачивание обновления v$tag") {
            val f = File(cacheDir, "update.apk")
            withContext(Dispatchers.IO) {
                val body = OkHttpClient().newCall(Request.Builder().url(url).build()).execute().body!!
                val total = body.contentLength()
                body.byteStream().use { i -> f.outputStream().use { o ->
                    val buf = ByteArray(65536); var done = 0L
                    while (true) { val n = i.read(buf); if (n < 0) break; o.write(buf, 0, n); done += n; if (total > 0) progress = done.toFloat() / total }
                } }
            }
            installApk(f)
        }
        fun doUpdate() = job("Проверка обновления") {
            val info = withContext(Dispatchers.IO) {
                val j = JSONObject(OkHttpClient().newCall(Request.Builder().url("https://api.github.com/repos/${BuildConfig.REPO}/releases/latest").build()).execute().body!!.string())
                val tag = j.optString("tag_name").removePrefix("v").toIntOrNull()
                var url: String? = null
                val a = j.optJSONArray("assets")
                if (a != null) for (i in 0 until a.length()) if (a.getJSONObject(i).getString("name").endsWith(".apk")) url = a.getJSONObject(i).getString("browser_download_url")
                if (tag != null && tag > BuildConfig.VERSION_CODE && url != null) tag to url else null
            }
            progress = 0f
            if (info == null) status = "Установлена последняя версия (v${BuildConfig.VERSION_CODE})"
            else { status = "Доступна версия v${info.first}"; updateInfo = info }
        }

        if (infoDialog) AlertDialog(
            onDismissRequest = { infoDialog = false },
            title = { Text("Информация о файле") },
            text = {
                Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    pendingName?.let { Text(it, fontWeight = FontWeight.SemiBold) }
                    InfoLine("Длительность", fmtDur(infoDuration))
                    InfoLine("Размер", if (pendingSize > 0L) fmtSize(pendingSize) else "—")
                    InfoLine("Дорожки", infoTracks.size.toString())
                    infoTracks.filter { it.type == "video" }.forEach { t ->
                        InfoLine("Видео", "${t.w}×${t.h} · ${"%.2f".format(t.fps)} fps · ${t.codec.uppercase()}")
                        InfoLine("Битрейт", levelText(fmtBps(t.bps), bitrateLevel(t.bps, t.w, t.h, t.fps, t.codec)))
                    }
                    infoTracks.filter { it.type == "audio" }.forEach { t ->
                        InfoLine("Звук ${t.lang}", levelText("${chLabel(t.ch)} · ${t.codec.uppercase()} · ${fmtBps(t.bps)}", audioLevel(t.bps, t.ch, t.codec)))
                    }
                    infoTracks.filter { it.type == "subtitle" }.forEach { t ->
                        InfoLine("Субтитры", "${t.codec.uppercase()} · ${t.lang}" + if (t.title.isNotBlank()) " · ${t.title}" else "")
                    }
                }
            },
            confirmButton = { TextButton({ infoDialog = false }) { Text("Закрыть") } }
        )

        updateInfo?.let { (tag, url) ->
            AlertDialog(
                onDismissRequest = { updateInfo = null },
                title = { Text("Доступно обновление") },
                text = { Text("Новая версия v$tag (сейчас v${BuildConfig.VERSION_CODE}). Скачать и установить поверх текущей?") },
                confirmButton = { TextButton({ updateInfo = null; downloadUpdate(tag, url) }) { Text("Скачать") } },
                dismissButton = { TextButton({ updateInfo = null }) { Text("Не сейчас") } }
            )
        }
        BackHandler {
            when {
                errorLogOpen -> errorLogOpen = false
                logOpen -> logOpen = false
                infoDialog -> infoDialog = false
                confirmOpen -> confirmOpen = false
                exitConfirmOpen -> exitConfirmOpen = false
                showSettings -> showSettings = false
                input != null && !busy -> leaveProject()
                else -> exitConfirmOpen = true
            }
        }
        if (exitConfirmOpen) AlertDialog(
            onDismissRequest = { exitConfirmOpen = false },
            title = { Text("Закрыть приложение?") },
            text = {
                Text(if (busy)
                    "Обработка видео ещё выполняется. Если выйти сейчас, обработка может быть прервана. Вы действительно хотите закрыть приложение?"
                else "Вы действительно хотите закрыть приложение?")
            },
            confirmButton = {
                TextButton(onClick = { exitConfirmOpen = false; finish() }) { Text("Закрыть") }
            },
            dismissButton = {
                TextButton(onClick = { exitConfirmOpen = false }) { Text("Отмена") }
            }
        )
        Column(Modifier.fillMaxSize().statusBarsPadding().imePadding()) {
            // Верхняя панель: стрелка «к проектам» слева, настройки справа
            Row(
                Modifier
                    .fillMaxWidth()
                    .heightIn(min = 56.dp) // Полупрозрачная шапка остаётся видимой поверх прокрутки
                    .background(MaterialTheme.colorScheme.background.copy(alpha = 0.55f))
                    .padding(start = 8.dp, end = 8.dp, top = 4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Стрелка видна только когда открыт проект и можно вернуться к списку проектов
                if (!showSettings && input != null) {
                    IconButton(onClick = { leaveProject() }, enabled = !busy) { Icon(Icons.Filled.ArrowBack, contentDescription = "К проектам") }
                } else Spacer(Modifier.height(48.dp))
                Spacer(Modifier.weight(1f))
                IconButton(onClick = { showSettings = !showSettings }) {
                    Icon(
                        Icons.Filled.Settings,
                        contentDescription = "Настройки",
                        tint = MaterialTheme.colorScheme.onBackground
                    )
                }
            }
            if (showSettings) {
                val cacheBytes = remember(showSettings, input, busy) { cacheDir.walkTopDown().filter { it.isFile }.sumOf { it.length() } }
                SettingsPanel(Modifier.weight(1f), themeMode, { themeMode = it; sp.edit().putString("theme", it).apply() },
                    BuildConfig.VERSION_CODE, busy, { doUpdate() }, "Занято в кеше: ${fmtSize(cacheBytes)}", { clearFile() }, { showSettings = false })
            } else {

            // Контент
            Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(horizontal = 16.dp, vertical = 8.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                SectionCard("Файл") {
                    val f = input
                    if (f == null) {
                        Text("Выберите видео MKV или MP4, чтобы увидеть дорожки и доступные действия.", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        pendingUri?.let { _ ->
                            HorizontalDivider()
                            Text("Выбранный оригинал · без копирования в кеш", style = MaterialTheme.typography.labelLarge)
                            Text("${pendingName ?: "video.mkv"} · ${if (pendingSize > 0L) fmtSize(pendingSize) else "размер неизвестен"}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 2, overflow = TextOverflow.Ellipsis)
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                OutlinedButton({ checkPendingInfo() }, enabled = !busy, modifier = Modifier.weight(1f).height(52.dp), shape = RoundedCornerShape(14.dp)) {
                                    Text("Посмотреть", maxLines = 2, textAlign = androidx.compose.ui.text.style.TextAlign.Center)
                                }
                                Button({ createPendingProject() }, enabled = !busy, modifier = Modifier.weight(1f).height(52.dp), shape = RoundedCornerShape(14.dp)) {
                                    Text("Создать проект", maxLines = 2, textAlign = androidx.compose.ui.text.style.TextAlign.Center)
                                }
                            }
                        }
                        saved?.let { sv ->
                            HorizontalDivider()
                            Text("Сохранённый проект", style = MaterialTheme.typography.labelLarge)
                            Text("${sv.file.name} · ${fmtSize(sv.file.length())} · ${sv.tracks.size} дорожек", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 2, overflow = TextOverflow.Ellipsis)
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                Button({ restoreProject() }, enabled = !busy, modifier = Modifier.weight(1f).height(52.dp), shape = RoundedCornerShape(14.dp)) { Text("Открыть") }
                                OutlinedButton({ clearFile() }, enabled = !busy, modifier = Modifier.weight(1f).height(52.dp), shape = RoundedCornerShape(14.dp)) { Text("Удалить проект") }
                            }
                        }
                    } else {
                        Text(f.name, style = MaterialTheme.typography.bodyLarge, fontWeight = FontWeight.Medium, maxLines = 2, overflow = TextOverflow.Ellipsis)
                        Text("${fmtDur(duration)} · ${fmtSize(f.length())} · ${tracks.size} дорожек", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        tracks.firstOrNull { it.type == "video" && it.w > 0 }?.let {
                            InfoLine("Видео", "${it.w}×${it.h} · ${"%.2f".format(it.fps)} fps · ${it.codec.uppercase()}")
                            InfoLine("Битрейт", levelText(fmtBps(it.bps), bitrateLevel(it.bps, it.w, it.h, it.fps, it.codec)))
                        }
                        tracks.filter { it.type == "audio" }.forEach { InfoLine("Звук ${it.lang}", levelText("${chLabel(it.ch)} · ${it.codec.uppercase()} · ${fmtBps(it.bps)}", audioLevel(it.bps, it.ch, it.codec))) }
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        FilledTonalButton({ picker.launch(arrayOf("video/*", "application/x-matroska")) }, enabled = !busy, modifier = Modifier.weight(1f).heightIn(min = 48.dp), shape = RoundedCornerShape(14.dp)) {
                            Text(if (input == null) "Выбрать файл" else "Другой файл")
                        }
                        if (input != null) OutlinedButton({ clearFile() }, enabled = !busy, modifier = Modifier.weight(1f).heightIn(min = 48.dp), shape = RoundedCornerShape(14.dp)) { Text("Очистить") }
                    }
                }

                if (input != null) {
                    val fileLen = input?.length() ?: 0L
                    val gbVal = gb.replace(',', '.').toDoubleOrNull()
                    val sizeTooBig = gbVal != null && gbVal > 0 && gbVal * 1073741824.0 >= fileLen
                    val videoOn = gbVal == null || gbVal > 0  // целевой размер больше исходного тоже применяется (перекодирование под заданный вес)
                    val scaleOn = false // Изменение соотношения сторон отключено: сохраняем исходный кадр.
                    val audioOn = comp > 0
                    val preset = (comp - 1).coerceAtLeast(0)
                    val aSel = tracks.filter { it.on && it.type == "audio" }
                    val sourceVideo = tracks.firstOrNull { it.type == "video" && it.on && it.w > 0 }
                    val sourceCodec = sourceVideo?.codec?.lowercase().orEmpty()
                    val sourceIsH264 = sourceCodec.startsWith("h264") || sourceCodec.startsWith("avc")
                    val h264OptionEnabled = sourceVideo != null && !sourceIsH264 && sourceCodec !in listOf("mjpeg", "png", "bmp")
                    if (!h264OptionEnabled && convertH264) convertH264 = false
                    val plan = buildPlan(tracks, fileLen, duration, videoOn, gbVal, false, 1080, audioOn, br51, brSt, speed, cal, convertH264)

                    CollapseCard("Дорожки", "Выбрано ${tracks.count { it.on }} из ${tracks.size}", tracksOpen, { tracksOpen = it }) {
                        Text("Нажмите на строку, чтобы включить или убрать дорожку.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        tracks.forEachIndexed { i, t -> TrackRow(t, !busy) { tracks[i] = t.copy(on = it) } }
                    }

                    CollapseCard("Обработка видео",
                        buildList { if (convertH264) add("перекодирование в H.264"); if (videoOn && gbVal != null) add("сжатие до ${gb.replace(',', '.')} ГБ"); if (hardware && plan.encode) add("Аппаратное ускорение") }.joinToString(" · ").let { if (it.isEmpty()) "Сжатие по размеру без изменения кадра" else "Включено: $it" },
                        videoOpen, { videoOpen = it }, spacing = 10.dp) {
                        OutlinedTextField(gb, { gb = it }, label = { Text("Целевой размер файла") }, suffix = { Text("ГБ") }, singleLine = true,
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(14.dp), enabled = !busy)
                        val hint = plan.error ?: when {
                            gbVal == null -> "Введите размер числом"
                            gbVal <= 0 -> "0 — сжатие по размеру отключено, вес файла не меняется"
                            duration <= 0 -> "Неизвестна длительность"
                            sizeTooBig -> "Больше исходного (${fmtSize(fileLen)}): файл будет перекодирован под заданный вес, качество не вырастет. Видео-битрейт ≈ ${fmtBps(plan.vBps)}"
                            else -> "Видео-битрейт ≈ ${fmtBps(plan.vBps)}"
                        }
                        Text(hint, style = MaterialTheme.typography.bodySmall, color = if (plan.error != null || gbVal == null) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.onSurfaceVariant)

                        HorizontalDivider()
                        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                            Checkbox(checked = convertH264, onCheckedChange = { convertH264 = it }, enabled = !busy && h264OptionEnabled)
                            Column(Modifier.weight(1f)) {
                                Text("Перекодировать в H.264", style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Medium,
                                    color = if (h264OptionEnabled) MaterialTheme.colorScheme.onSurface else MaterialTheme.colorScheme.onSurface.copy(alpha = 0.38f))
                                Text(if (sourceIsH264) "Исходное видео уже использует H.264." else "Преобразовать видеодорожку в совместимый формат H.264.",
                                    style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                        }
                        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                            Checkbox(checked = hardware, onCheckedChange = { hardware = it }, enabled = !busy && plan.encode)
                            Column(Modifier.weight(1f)) {
                                Text("Аппаратное ускорение (быстрее)", style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Medium)
                                Text("MediaCodec; при ошибке автоматически включится libx264 medium.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                        }

                        if (plan.encode) {
                            HorizontalDivider()
                            Text("Скорость кодирования", style = MaterialTheme.typography.labelLarge)
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                SPEEDS.forEachIndexed { i, sp ->
                                    FilterChip(speed == i, { speed = i }, {
                                        Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
                                            Text(sp.first, fontSize = 13.sp, maxLines = 1)
                                            Text(fmtTime(duration / encSpeed(if (hardware) 1 else i, plan.outW * plan.outH, plan.fps, cal) / if (hardware) 3.0 else 1.0), fontSize = 11.sp, maxLines = 1)
                                        }
                                    }, Modifier.weight(1f), enabled = !hardware && !busy)
                                }
                            }
                            Text(if (hardware) "При аппаратном ускорении пресет не применяется; качество задаётся битрейтом." else SPEED_NOTES[speed], style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            Text((if (cal[speed] > 0) "Время рассчитано по прошлой обработке на этом телефоне." else "Время примерное; после первой обработки уточнится.") + if (hardware) " (с аппаратным ускорением)" else "",
                                style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }

                    CollapseCard("Сжатие звука",
                        if (comp > 0) "Компрессор: ${PRESETS[preset].first}" else "Выравнивает громкость, звук кодируется в AC-3",
                        audioOpen, { audioOpen = it }, spacing = 10.dp) {
                        Text("Компрессор", style = MaterialTheme.typography.labelLarge)
                        val opts = listOf("Не сжимать" to "Звук остаётся как в оригинале, без перекодирования.") + PRESETS.map { it.first to it.second }
                        opts.forEachIndexed { i, (name, desc) ->
                            Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).clickable(enabled = !busy) { comp = i }.padding(vertical = 2.dp), verticalAlignment = Alignment.Top) {
                                RadioButton(comp == i, null, enabled = !busy, modifier = Modifier.padding(top = 2.dp))
                                Spacer(Modifier.width(8.dp))
                                Column(Modifier.weight(1f)) {
                                    Text(name, style = MaterialTheme.typography.bodyLarge, fontWeight = FontWeight.Medium)
                                    Text(desc, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                            }
                        }
                        if (comp > 0) {
                            HorizontalDivider()
                            if (aSel.any { it.ch >= 6 }) {
                                Text("Битрейт для 5.1", style = MaterialTheme.typography.labelLarge)
                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) { listOf(448, 640).forEach { b -> FilterChip(br51 == b, { br51 = b }, { Text("$b кбит/с") }, enabled = !busy) } }
                            }
                            if (aSel.any { it.ch < 6 }) {
                                Text("Битрейт для стерео", style = MaterialTheme.typography.labelLarge)
                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) { listOf(192, 256).forEach { b -> FilterChip(brSt == b, { brSt = b }, { Text("$b кбит/с") }, enabled = !busy) } }
                            }
                            Text("Больше битрейт — лучше звук и больше вес файла.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            if (aSel.isEmpty()) Text("Не выбрано ни одной аудиодорожки", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.error)
                        }
                    }

                    SectionCard("Результат") {
                        val removedN = tracks.count { !it.on }
                        val applied = buildList {
                            if (removedN > 0) add("• Убрано дорожек: $removedN")
                            if (convertH264) add("• Видео перекодировано в H.264")
                            if (plan.encode && videoOn) add("• Видео сжато до ${gb.replace(',', '.')} ГБ")
                            if (plan.encode && hardware) add("• Аппаратное ускорение MediaCodec (fallback libx264)")
                            if (plan.encode) add("• Скорость кодирования: ${SPEEDS[speed].first}")
                            if (audioOn && aSel.isNotEmpty()) add("• Компрессор: ${PRESETS[preset].first}, AC-3" + (if (aSel.any { it.ch >= 6 }) " 5.1 ${br51}k" else "") + (if (aSel.any { it.ch < 6 }) " стерео ${brSt}k" else ""))
                        }
                        val hasChange = applied.isNotEmpty()
                        val summary: @Composable ColumnScope.() -> Unit = {
                        Text(if (hasChange) applied.joinToString("\n") else "Изменений нет — запуск недоступен, чтобы не перекодировать видео зря.", style = MaterialTheme.typography.bodyMedium)
                        HorizontalDivider()
                        if (plan.error != null) Text(plan.error, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodyMedium)
                        val lvOld = bitrateLevel(plan.origV, plan.origW, plan.origH, plan.fps, plan.codec)
                        val lvNew = if (plan.encode) bitrateLevel(plan.vBps, plan.outW, plan.outH, plan.fps, "h264") else lvOld
                        val sizeChanged = kotlin.math.abs(plan.size - fileLen) > 1_048_576L
                        DiffLine("Вес", AnnotatedString(fmtSize(fileLen)), AnnotatedString("≈ " + fmtSize(plan.size)), sizeChanged)
                        if (plan.hasVideo) {
                            val resOld = "${plan.origW}×${plan.origH}"
                            val resNew = "${plan.outW}×${plan.outH}"
                            DiffLine("Разрешение", AnnotatedString(resOld), AnnotatedString(resNew), plan.outW != plan.origW || plan.outH != plan.origH)
                            val sourceAverageBps = if (duration > 0.0 && fileLen > 0L) (fileLen * 8.0 / duration).toLong() else plan.origV
                            val estimatedOutputBps = if (duration > 0.0 && plan.size > 0L) (plan.size * 8.0 / duration).toLong() else plan.vBps
                            val shownOutputBps = actualOutputBitrate ?: estimatedOutputBps
                            val brOld = AnnotatedString(fmtBps(sourceAverageBps))
                            val brNew = AnnotatedString(fmtBps(shownOutputBps) + if (actualOutputBitrate != null) " · факт" else " · оценка")
                            DiffLine("Средний битрейт файла", brOld, brNew, brOld.text != brNew.text)
                        }
                        aSel.forEach { t ->
                            val newBps = (if (t.ch >= 6) br51 else brSt) * 1000L
                            val old = levelText("${chLabel(t.ch)} · ${fmtBps(t.bps)}", audioLevel(t.bps, t.ch, t.codec))
                            val new = if (audioOn) levelText("${chLabel(t.ch)} · AC3 · ${fmtBps(newBps)}", audioLevel(newBps, t.ch, "ac3")) else old
                            DiffLine("Звук ${t.lang}", old, new, audioOn)
                        }
                        InfoLine("Время", fmtTime(plan.time / if (hardware && plan.encode) 3.0 else 1.0) + if (hardware && plan.encode) " (с аппаратным ускорением)" else "", 112.dp)
                        }
                        summary()
                        val startJob: () -> Unit = {
                            job("Обработка файла", true) {
                                val chosen = tracks.filter { it.on }
                                if (chosen.isEmpty()) { status = "Выберите хотя бы одну дорожку"; progress = 0f; return@job }
                                if (plan.error != null) { status = plan.error; progress = 0f; return@job }
                                if (!storageOk()) return@job
                                val dir = outDir(); val need = (plan.size * 1.1).toLong() + 200L * 1024 * 1024
                                if (dir.usableSpace < need) {
                                    status = "Мало места: нужно ≈ ${fmtSize(need)}, свободно ${fmtSize(dir.usableSpace)}"; progress = 0f
                                    log(status); Notif.done(this@MainActivity, "Недостаточно места", status); return@job
                                }
                                val vSel = chosen.filter { it.type == "video" }
                                val aSel2 = chosen.filter { it.type == "audio" }
                                if (audioOn && aSel2.isEmpty()) log("Предупреждение: звук не выбран")
                                logs.clear()
                                failedCommand = ""
                                log("=== Начало обработки ===")
                                log("Входной файл: ${input!!.absolutePath}")
                                val out = outFile("edit")
                                val videoStream = vSel.indexOfFirst { it.codec !in listOf("mjpeg", "png", "bmp") }
                                fun makeCommand(encoder: String?): List<String> {
                                    val args = mutableListOf(bm.ffmpeg, "-hide_banner", "-y", "-nostats", "-progress", "pipe:1", "-i", input!!.absolutePath)
                                    chosen.forEach { args += listOf("-map", "0:${it.index}") }
                                    args += listOf("-c", "copy")
                                    if (chosen.any { it.type == "subtitle" && it.codec == "mov_text" }) args += listOf("-c:s", "srt")
                                    if (audioOn && aSel2.isNotEmpty()) {
                                        args += listOf("-c:a", "ac3", "-af", PRESETS[preset].third)
                                        aSel2.forEachIndexed { n, t ->
                                            val five = t.ch >= 6
                                            args += listOf("-b:a:$n", "${if (five) br51 else brSt}k")
                                            if (five) args += listOf("-ac:a:$n", "6")
                                        }
                                    }
                                    if (plan.encode && videoStream >= 0 && encoder != null) {
                                        val targetK = ((plan.vBps + 500L) / 1000L).coerceAtLeast(1L)
                                        val targetRate = "${targetK}k"
                                        args += listOf("-c:v:$videoStream", encoder, "-b:v:$videoStream", targetRate,
                                            "-maxrate:v:$videoStream", targetRate,
                                            "-bufsize:v:$videoStream", "${targetK * 2}k")
                                        if (encoder == "h264_mediacodec") {
                                            // Без этого аппаратный кодер работает в VBR и сильно занижает битрейт
                                            args += listOf("-bitrate_mode", "cbr")
                                        }
                                        if (encoder != "h264_mediacodec") {
                                            args += listOf("-pix_fmt:v:$videoStream", "yuv420p", "-preset:v:$videoStream", if (hardware) "medium" else SPEEDS[speed].second)
                                        }

                                    }
                                    args += out
                                    return args
                                }
                                val t0 = System.nanoTime()
                                var usedEncoder = if (plan.encode && videoStream >= 0) if (hardware) "h264_mediacodec" else "libx264" else null
                                if (usedEncoder == "h264_mediacodec") {
                                    log("Кодер: h264_mediacodec, видео ${plan.vBps / 1000} кбит/с")
                                } else if (usedEncoder != null) {
                                    log("Кодер: libx264, preset ${SPEEDS[speed].second}, видео ${plan.vBps / 1000} кбит/с")
                                }
                                run(makeCommand(usedEncoder), track = true)
                                val retrySw = usedEncoder == "h264_mediacodec" && rs.exit != 0 && !rs.stopped
                                if (retrySw) {
                                    log("MediaCodec завершился с ошибкой (код ${rs.exit}); повторяю обработку через libx264 preset medium")
                                    File(out).delete()
                                    usedEncoder = "libx264"
                                    run(makeCommand("libx264"), track = true)
                                }
                                val el = (System.nanoTime() - t0) / 1e9
                                if (rs.exit == 0 && usedEncoder == "libx264" && el > 20 && duration > 0) {
                                    val norm = duration / el * (plan.outW * plan.outH) / 2_073_600.0 * (plan.fps.coerceIn(24.0, 60.0) / 24.0)
                                    prefs.edit().putFloat("cal_$speed", norm.toFloat()).apply(); calTick++
                                }
                                finish(out)
                            }
                        }
                        if (errorLogOpen) AlertDialog(
                            onDismissRequest = { errorLogOpen = false },
                            title = { Text("Ошибка обработки — лог") },
                            text = {
                                Column(Modifier.fillMaxWidth().heightIn(max = 520.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                    Text("Последняя команда с ошибкой", fontWeight = FontWeight.SemiBold)
                                    SelectionContainer {
                                        Text(failedCommand.ifBlank { "Команда не определена" }, fontFamily = FontFamily.Monospace, fontSize = 11.sp)
                                    }
                                    Divider()
                                    Text("Полный лог обработки", fontWeight = FontWeight.SemiBold)
                                    Box(Modifier.weight(1f, fill = false).fillMaxWidth().heightIn(max = 300.dp).background(Color(0xFF101418), RoundedCornerShape(8.dp)).verticalScroll(rememberScrollState()).padding(10.dp)) {
                                        SelectionContainer {
                                            Text(logs.joinToString("\n"), fontFamily = FontFamily.Monospace, fontSize = 10.sp, color = Color(0xFFB8F5B8))
                                        }
                                    }
                                }
                            },
                            confirmButton = {
                                TextButton(onClick = {
                                    val report = "Последняя команда с ошибкой:\n${failedCommand.ifBlank { "не определена" }}\n\nПолный лог:\n${logs.joinToString("\n")}"
                                    clipboard.setText(AnnotatedString(report))
                                }) { Text("Копировать лог") }
                            },
                            dismissButton = { TextButton(onClick = { errorLogOpen = false }) { Text("Закрыть") } }
                        )
                        if (confirmOpen) AlertDialog(
                            onDismissRequest = { confirmOpen = false },
                            title = { Text("Запустить обработку?") },
                            text = { Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) { summary() } },
                            confirmButton = { TextButton({ confirmOpen = false; startJob() }) { Text("Запустить") } },
                            dismissButton = { TextButton({ confirmOpen = false }) { Text("Отмена") } }
                        )
                        Button({ confirmOpen = true }, enabled = !busy && hasChange && plan.error == null, modifier = Modifier.fillMaxWidth().heightIn(min = 52.dp), shape = RoundedCornerShape(16.dp)) { Text("Запустить обработку", fontWeight = FontWeight.SemiBold) }
                    }
                }
                Spacer(Modifier.height(8.dp))
            }

            }

            // Нижняя панель: прогресс + выдвижной лог
            Surface(Modifier.fillMaxWidth(), color = MaterialTheme.colorScheme.surfaceContainerHigh,
                shape = RoundedCornerShape(topStart = 24.dp, topEnd = 24.dp), shadowElevation = 8.dp) {
                Column(Modifier.navigationBarsPadding().padding(horizontal = 16.dp, vertical = 6.dp)) {
                    Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).clickable { logOpen = !logOpen }.padding(vertical = 2.dp),
                        horizontalArrangement = Arrangement.Center, verticalAlignment = Alignment.CenterVertically) {
                        Icon(if (logOpen) Icons.Filled.KeyboardArrowDown else Icons.Filled.KeyboardArrowUp, contentDescription = "Лог")
                        Text("Лог", style = MaterialTheme.typography.labelLarge)
                        Spacer(Modifier.width(8.dp))
                        TextButton(onClick = {
                            val report = "Последняя команда с ошибкой:\n${failedCommand.ifBlank { "нет" }}\n\nЛог:\n${logs.joinToString("\n")}"
                            clipboard.setText(AnnotatedString(report))
                        }) { Text("Копировать") }
                    }
                    val p = progress
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(status, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Medium, maxLines = 2, overflow = TextOverflow.Ellipsis)
                            if (speedTxt.isNotEmpty()) Text("скорость $speedTxt", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        if (busy && p != null) Text("${(p * 100).toInt()}%", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                        if (busy && p != null) TextButton(onClick = { stopProcess() }) { Text("Стоп") }
                    }
                    // Прогресс-бар виден только пока что-то происходит
                    if (busy) {
                        val bar = Modifier.fillMaxWidth().height(8.dp).clip(RoundedCornerShape(4.dp))
                        if (p == null) LinearProgressIndicator(bar) else LinearProgressIndicator(progress = { p }, modifier = bar)
                    }
                    AnimatedVisibility(logOpen, enter = expandVertically(expandFrom = Alignment.Bottom) + fadeIn(), exit = shrinkVertically(shrinkTowards = Alignment.Bottom) + fadeOut()) {
                        val sc = rememberScrollState()
                        LaunchedEffect(logs.size) { sc.scrollTo(sc.maxValue) }
                        Box(Modifier.fillMaxWidth().padding(top = 10.dp, bottom = 6.dp).height(240.dp).clip(RoundedCornerShape(12.dp)).background(Color(0xFF101418)).verticalScroll(sc).padding(10.dp)) {
                            SelectionContainer { Text(logs.joinToString("\n"), fontFamily = FontFamily.Monospace, fontSize = 11.sp, color = Color(0xFFB8F5B8)) }
                        }
                    }
                    Spacer(Modifier.height(6.dp))
                }
            }
        }
    }
}

/** Увеличенная высота строки: на некоторых телефонах (MIUI и др.) шрифт выше стандартного и верх букв срезается. */
private fun TextStyle.roomy(): TextStyle = if (lineHeight.isSp) copy(lineHeight = (lineHeight.value * 1.3f).sp) else this
fun roomyTypography(): Typography {
    val t = Typography()
    return t.copy(
        displayLarge = t.displayLarge.roomy(), displayMedium = t.displayMedium.roomy(), displaySmall = t.displaySmall.roomy(),
        headlineLarge = t.headlineLarge.roomy(), headlineMedium = t.headlineMedium.roomy(), headlineSmall = t.headlineSmall.roomy(),
        titleLarge = t.titleLarge.roomy(), titleMedium = t.titleMedium.roomy(), titleSmall = t.titleSmall.roomy(),
        bodyLarge = t.bodyLarge.roomy(), bodyMedium = t.bodyMedium.roomy(), bodySmall = t.bodySmall.roomy(),
        labelLarge = t.labelLarge.roomy(), labelMedium = t.labelMedium.roomy(), labelSmall = t.labelSmall.roomy())
}

@Composable
fun AppTheme(mode: String = "system", content: @Composable () -> Unit) {
    val dark = isSystemInDarkTheme()
    val ctx = LocalContext.current
    val cs = when (mode) {
        "light" -> lightColorScheme()
        "dark" -> darkColorScheme()
        else -> when {   // «Системная»: цвета из системы (Android 12+), светлая/тёмная как в системе
            Build.VERSION.SDK_INT >= 31 -> if (dark) dynamicDarkColorScheme(ctx) else dynamicLightColorScheme(ctx)
            dark -> darkColorScheme()
            else -> lightColorScheme()
        }
    }
    val isDark = when (mode) { "dark" -> true; "light" -> false; else -> dark }
    val view = LocalView.current
    if (!view.isInEditMode) SideEffect {
        val w = (view.context as? Activity)?.window ?: return@SideEffect
        WindowCompat.setDecorFitsSystemWindows(w, false)
        w.statusBarColor = android.graphics.Color.TRANSPARENT
        w.navigationBarColor = android.graphics.Color.TRANSPARENT
        if (Build.VERSION.SDK_INT >= 29) w.isNavigationBarContrastEnforced = false
        WindowCompat.getInsetsController(w, view).apply { isAppearanceLightStatusBars = !isDark; isAppearanceLightNavigationBars = !isDark }
    }
    MaterialTheme(colorScheme = cs, typography = roomyTypography(), content = content)
}

@Composable
fun SectionCard(title: String, subtitle: String? = null, content: @Composable ColumnScope.() -> Unit) {
    Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(20.dp), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerHigh)) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text(title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
            if (subtitle != null) Text(subtitle, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            content()
        }
    }
}

@Composable
fun TrackRow(t: Track, enabled: Boolean = true, onToggle: (Boolean) -> Unit) {
    val cs = MaterialTheme.colorScheme
    val (label, bg, fg) = when (t.type) {
        "video" -> Triple("ВИДЕО", cs.primaryContainer, cs.onPrimaryContainer)
        "audio" -> Triple("АУДИО", cs.tertiaryContainer, cs.onTertiaryContainer)
        "subtitle" -> Triple("СУБТ", cs.secondaryContainer, cs.onSecondaryContainer)
        else -> Triple(t.type.uppercase(), cs.surfaceVariant, cs.onSurfaceVariant)
    }
    Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).clickable(enabled = enabled) { onToggle(!t.on) }.padding(vertical = 2.dp), verticalAlignment = Alignment.CenterVertically) {
        Checkbox(t.on, null, enabled = enabled)
        Spacer(Modifier.width(6.dp))
        Box(Modifier.clip(RoundedCornerShape(6.dp)).background(bg).padding(horizontal = 6.dp, vertical = 2.dp)) {
            Text(label, color = fg, fontSize = 10.sp, fontWeight = FontWeight.Bold)
        }
        Spacer(Modifier.width(10.dp))
        Column(Modifier.weight(1f)) {
            Text("#${t.index} ${t.codec.uppercase()}" + when (t.type) { "video" -> " · ${t.w}×${t.h} · ${fmtBps(t.bps)}"; "audio" -> " · ${chLabel(t.ch)} · ${fmtBps(t.bps)}"; else -> "" }, style = MaterialTheme.typography.bodyMedium, maxLines = 2, overflow = TextOverflow.Ellipsis)
            val sub = listOf(t.lang, t.title).filter { it.isNotBlank() }.joinToString(" · ")
            if (sub.isNotEmpty()) Text(sub, style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
    }
}

@Composable
fun InfoLine(label: String, value: String, w: Dp = 96.dp) = InfoLine(label, AnnotatedString(value), w)

@Composable
fun InfoLine(label: String, value: AnnotatedString, w: Dp = 96.dp) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Text(label, Modifier.width(w), style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold)
        Text(value, Modifier.weight(1f), style = MaterialTheme.typography.bodySmall)
    }
}

/** Строка «было → станет». Если ничего не меняется — одно значение и пометка. */
@Composable
fun DiffLine(label: String, before: AnnotatedString, after: AnnotatedString, changed: Boolean) {
    Row(verticalAlignment = Alignment.Top) {
        Text(label, Modifier.width(112.dp), style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold)
        Column(Modifier.weight(1f)) {
            if (changed) {
                Text(before, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Text(buildAnnotatedString { append("→ "); append(after) }, style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.SemiBold)
            } else {
                Text(buildAnnotatedString { append(after); withStyle(SpanStyle(color = Color.Gray)) { append("  · без изменений") } }, style = MaterialTheme.typography.bodySmall)
            }
        }
    }
}

/** Сворачиваемая вкладка со стрелкой (изначально закрыта). */
@Composable
fun CollapseCard(title: String, subtitle: String, expanded: Boolean, onToggle: (Boolean) -> Unit, spacing: Dp = 6.dp, content: @Composable ColumnScope.() -> Unit) {
    Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(20.dp), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerHigh)) {
        Column(Modifier.padding(16.dp)) {
            Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).clickable { onToggle(!expanded) }.padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                    Text(subtitle, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                Spacer(Modifier.width(8.dp))
                Icon(if (expanded) Icons.Filled.KeyboardArrowUp else Icons.Filled.KeyboardArrowDown, contentDescription = null, modifier = Modifier.size(28.dp))
            }
            AnimatedVisibility(expanded) {
                Column(Modifier.padding(top = 10.dp), verticalArrangement = Arrangement.spacedBy(spacing)) { content() }
            }
        }
    }
}


@Composable
fun SettingsPanel(modifier: Modifier, theme: String, onTheme: (String) -> Unit,
                  version: Int, busy: Boolean, onUpdate: () -> Unit, cacheText: String, onClearCache: () -> Unit, onBack: () -> Unit) {
    Column(modifier) {
        Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(horizontal = 16.dp, vertical = 8.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            SectionCard("Тема") {
                listOf(
                    Triple("system", "Системная", "Цвета берутся из системы (обои и тема телефона, Android 12+), светлая или тёмная — как в системе."),
                    Triple("light", "Светлая", "Всегда светлая, обычные цвета приложения."),
                    Triple("dark", "Тёмная", "Всегда тёмная, независимо от системы.")
                ).forEach { (key, name, desc) ->
                    Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).clickable { onTheme(key) }.padding(vertical = 2.dp), verticalAlignment = Alignment.Top) {
                        RadioButton(theme == key, null, modifier = Modifier.padding(top = 2.dp))
                        Spacer(Modifier.width(8.dp))
                        Column(Modifier.weight(1f)) {
                            Text(name, style = MaterialTheme.typography.bodyLarge, fontWeight = FontWeight.Medium)
                            Text(desc, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                }
            }
            SectionCard("Обновления") {
                Text("Установлена версия v$version", style = MaterialTheme.typography.bodyMedium)
                Button(onUpdate, enabled = !busy, modifier = Modifier.fillMaxWidth().heightIn(min = 48.dp), shape = RoundedCornerShape(14.dp)) { Text("Проверить обновления") }
            }
            SectionCard("Память") {
                Text(cacheText, style = MaterialTheme.typography.bodyMedium)
                Text("Файл и дорожки проекта хранятся в кеше, чтобы к ним можно было вернуться после перезапуска. Очистка удалит и проект.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                OutlinedButton(onClearCache, enabled = !busy, modifier = Modifier.fillMaxWidth().heightIn(min = 48.dp), shape = RoundedCornerShape(14.dp)) { Text("Очистить проект и кеш") }
            }
            val linkCtx = LocalContext.current
            fun openLink(url: String) { runCatching { linkCtx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } }
            SectionCard("Ссылки") {
                OutlinedButton({ openLink("https://t.me/josywtf") }, modifier = Modifier.fillMaxWidth().heightIn(min = 48.dp), shape = RoundedCornerShape(14.dp)) { Text("Telegram · t.me/josywtf") }
                OutlinedButton({ openLink("https://4pda.to/forum/index.php?showuser=11268484") }, modifier = Modifier.fillMaxWidth().heightIn(min = 48.dp), shape = RoundedCornerShape(14.dp)) { Text("4PDA · профиль на форуме") }
            }
            Column(Modifier.fillMaxWidth().padding(vertical = 16.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                Text("MkvTool", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                Text("v$version", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
    }
}
