package com.mkvtool

import android.content.Context
import okhttp3.OkHttpClient
import okhttp3.Request
import org.apache.commons.compress.archivers.tar.TarArchiveInputStream
import org.tukaani.xz.XZInputStream
import java.io.File

/** Копирует бинарники из assets/bin/arm64-v8a, а если их нет — скачивает при первом запуске. */
class BinaryManager(private val ctx: Context) {
    private val dir = File(ctx.filesDir, "bin").apply { mkdirs() }
    val ffmpeg get() = File(dir, "ffmpeg").absolutePath
    val ffprobe get() = File(dir, "ffprobe").absolutePath
    val mkvmerge get() = File(dir, "mkvmerge").absolutePath
    val ready get() = File(dir, "ffmpeg").canExecute() && File(dir, "ffprobe").canExecute()

    private fun chmod(f: File) {
        ProcessBuilder("chmod", "755", f.absolutePath).start().waitFor()
        f.setExecutable(true, false)
    }

    fun ensure(log: (String) -> Unit) {
        if (ready) return
        for (n in listOf("ffmpeg", "ffprobe", "mkvmerge")) {
            try {
                ctx.assets.open("bin/arm64-v8a/$n").use { i -> File(dir, n).outputStream().use { i.copyTo(it) } }
                chmod(File(dir, n)); log("assets: $n")
            } catch (_: Exception) {}
        }
        if (ready) return
        log("Скачиваю ffmpeg (~40 МБ)...")
        val tmp = File(ctx.cacheDir, "ffmpeg.tar.xz")
        val resp = OkHttpClient().newCall(Request.Builder().url(FFMPEG_URL).build()).execute()
        if (!resp.isSuccessful) error("HTTP ${resp.code}")
        resp.body!!.byteStream().use { i -> tmp.outputStream().use { i.copyTo(it) } }
        log("Распаковка...")
        TarArchiveInputStream(XZInputStream(tmp.inputStream().buffered())).use { tar ->
            while (true) {
                val e = tar.nextTarEntry ?: break
                val name = e.name.substringAfterLast('/')
                if (!e.isDirectory && (name == "ffmpeg" || name == "ffprobe")) {
                    val f = File(dir, name)
                    f.outputStream().use { tar.copyTo(it) }; chmod(f); log("OK: $name")
                }
            }
        }
        tmp.delete()
        if (!ready) error("Бинарники не установлены")
    }

    companion object {
        const val FFMPEG_URL = "https://johnvansickle.com/ffmpeg/releases/ffmpeg-release-arm64-static.tar.xz"
    }
}
