package com.mkvtool

import android.content.Context
import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.File
import java.util.zip.ZipInputStream

/** Скачивает ffmpeg/ffprobe, собранные под Android (bionic), при первом запуске. */
class BinaryManager(private val ctx: Context) {
    private val dir = File(ctx.filesDir, "bin").apply { mkdirs() }
    private val marker = File(dir, ".v2")
    val ffmpeg get() = File(dir, "ffmpeg").absolutePath
    val ffprobe get() = File(dir, "ffprobe").absolutePath
    val ready get() = marker.exists() && File(dir, "ffmpeg").canExecute() && File(dir, "ffprobe").canExecute()

    private fun chmod(f: File) {
        runCatching { ProcessBuilder("chmod", "755", f.absolutePath).start().waitFor() }
        f.setExecutable(true, false)
    }

    fun ensure(log: (String) -> Unit) {
        if (!android.os.Build.SUPPORTED_ABIS.contains("arm64-v8a"))
            error("Приложение работает только на 64-битных телефонах (arm64-v8a). Ваш телефон: ${android.os.Build.SUPPORTED_ABIS.joinToString()}")
        if (ready) return
        dir.listFiles()?.forEach { it.delete() } // убрать старые glibc-бинарники (SIGSYS)
        log("Скачиваю ffmpeg для Android...")
        val resp = OkHttpClient().newCall(Request.Builder().url(FFMPEG_URL).build()).execute()
        if (!resp.isSuccessful) error("HTTP ${resp.code}")
        ZipInputStream(resp.body!!.byteStream().buffered()).use { zip ->
            while (true) {
                val e = zip.nextEntry ?: break
                val name = e.name.substringAfterLast('/')
                if (!e.isDirectory && (name == "ffmpeg" || name == "ffprobe")) {
                    val f = File(dir, name)
                    f.outputStream().use { zip.copyTo(it) }; chmod(f); log("OK: $name")
                }
            }
        }
        if (!(File(dir, "ffmpeg").exists() && File(dir, "ffprobe").exists())) error("В архиве нет ffmpeg/ffprobe")
        marker.writeText("2")
    }

    companion object {
        const val FFMPEG_URL = "https://github.com/chomusuke-mk/vidra-ffmpeg/releases/latest/download/ffmpeg-android-arm64-v8a.zip"
    }
}
