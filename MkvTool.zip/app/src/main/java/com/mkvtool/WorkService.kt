package com.mkvtool

import android.app.Service
import android.content.Intent
import android.os.IBinder
import android.os.PowerManager

/** Фоновая служба: держит процесс живым и CPU включённым (PARTIAL_WAKE_LOCK), пока идёт обработка. */
class WorkService : Service() {
    private var wl: PowerManager.WakeLock? = null
    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        startForeground(Notif.ID_WORK, Notif.work(this, "Обработка…", null))
        if (wl == null) {
            wl = (getSystemService(POWER_SERVICE) as PowerManager).newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "mkvtool:work")
                .apply { acquire(12 * 60 * 60 * 1000L) }
        }
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        wl?.let { if (it.isHeld) it.release() }
        wl = null
        super.onDestroy()
    }
}
