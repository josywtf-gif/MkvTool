package com.mkvtool

import android.app.Service
import android.content.Intent
import android.os.IBinder
import android.os.PowerManager

/** Служба работает только во время длительной обработки. В ожидании WakeLock не удерживается. */
class WorkService : Service() {
    private var wakeLock: PowerManager.WakeLock? = null
    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> {
                releaseWakeLock()
                stopForeground(STOP_FOREGROUND_REMOVE)
                stopSelfResult(startId)
            }
            ACTION_START -> {
                startForeground(Notif.ID_WORK, Notif.work(this, "Обработка…", null))
                acquireWakeLock()
            }
            else -> stopSelfResult(startId)
        }
        return START_NOT_STICKY
    }

    private fun acquireWakeLock() {
        if (wakeLock?.isHeld == true) return
        wakeLock = (getSystemService(POWER_SERVICE) as PowerManager)
            .newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "mkvtool:encoding")
            .apply { setReferenceCounted(false); acquire(12 * 60 * 60 * 1000L) }
    }

    private fun releaseWakeLock() {
        wakeLock?.let { if (it.isHeld) it.release() }
        wakeLock = null
    }

    override fun onDestroy() {
        releaseWakeLock()
        super.onDestroy()
    }

    companion object {
        const val ACTION_START = "com.mkvtool.action.START_WORK"
        const val ACTION_STOP = "com.mkvtool.action.STOP_WORK"
    }
}
