plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.mkvtool"
    compileSdk = 34
    defaultConfig {
        applicationId = "com.mkvtool"
        minSdk = 24
        // targetSdk 28: Android 10+ запрещает exec из filesDir при targetSdk >= 29
        targetSdk = 28
        versionCode = (findProperty("vc") ?: "1").toString().toInt()
        versionName = "1.$versionCode"
        buildConfigField("String", "REPO", "\"${findProperty("slug") ?: "OWNER/REPO"}\"")
    }
    signingConfigs {
        create("rel") {
            storeFile = rootProject.file("release.keystore")
            storePassword = "mkvtool123"; keyAlias = "mkv"; keyPassword = "mkvtool123"
        }
    }
    buildTypes {
        release {
            isMinifyEnabled = false
            signingConfig = signingConfigs.getByName("rel")
        }
    }
    compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
    kotlinOptions { jvmTarget = "17" }
    buildFeatures { compose = true; buildConfig = true }
    composeOptions { kotlinCompilerExtensionVersion = "1.5.8" }
    packaging { resources.excludes += "/META-INF/{AL2.0,LGPL2.1}" }
}
dependencies {
    implementation(platform("androidx.compose:compose-bom:2024.02.00"))
    implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.ui:ui")
    implementation("androidx.activity:activity-compose:1.8.2")
    implementation("androidx.core:core-ktx:1.12.0")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.7.3")
    implementation("com.squareup.okhttp3:okhttp:4.12.0")
    implementation("org.apache.commons:commons-compress:1.26.0")
    implementation("org.tukaani:xz:1.9")
}
